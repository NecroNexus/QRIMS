const API_BASE = import.meta.env.VITE_API_URL || '/api';

class ApiClient {
  constructor() {
    this.token = localStorage.getItem('qrims_token');
  }

  setToken(token) {
    this.token = token;
    if (token) localStorage.setItem('qrims_token', token);
    else localStorage.removeItem('qrims_token');
  }

  async request(path, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...options.headers };
    if (this.token) headers.Authorization = `Bearer ${this.token}`;

    const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
    const data = await res.json().catch(() => ({}));

    if (!res.ok) throw new Error(data.message || 'Request failed');
    return data;
  }

  get(path) { return this.request(path); }
  post(path, body) { return this.request(path, { method: 'POST', body: JSON.stringify(body) }); }
  put(path, body) { return this.request(path, { method: 'PUT', body: JSON.stringify(body) }); }
  delete(path) { return this.request(path, { method: 'DELETE' }); }

  login(email, password) {
    return this.post('/auth/login', { email, password }).then((d) => {
      this.setToken(d.data.token);
      return d;
    });
  }

  logout() { this.setToken(null); }

  onboarding(data) {
    return this.post('/auth/onboarding', data).then((d) => {
      this.setToken(d.data.token);
      return d;
    });
  }

  getMe() { return this.get('/auth/me'); }
  getAnalytics() { return this.get('/analytics'); }
  getInventory(params = '') { return this.get(`/inventory?${params}`); }
  getInventoryItem(id) { return this.get(`/inventory/${id}`); }
  createInventoryItem(data) { return this.post('/inventory', data); }
  updateInventoryItem(id, data) { return this.put(`/inventory/${id}`, data); }
  deleteInventoryItem(id) { return this.delete(`/inventory/${id}`); }
  stockIn(id, data) { return this.post(`/inventory/${id}/stock-in`, data); }
  stockOut(id, data) { return this.post(`/inventory/${id}/stock-out`, data); }
  getQr(id) { return this.get(`/inventory/${id}/qr`); }
  searchInventory(q) { return this.get(`/inventory/search?q=${encodeURIComponent(q)}`); }
  getDepartments() { return this.get('/departments'); }
  getCategories() { return this.get('/categories'); }
  getUsers() { return this.get('/users'); }
  getTemplate() { return this.get('/template'); }
  updateTemplate(data) { return this.put('/template', data); }
  getMaintenance() { return this.get('/maintenance'); }
  updateMaintenance(id, data) { return this.put(`/maintenance/${id}`, data); }
  getExpiring(days = 30) { return this.get(`/inventory/expiring?days=${days}`); }
  getTransactions(id) { return this.get(`/inventory/${id}/transactions`); }
  getPredictions() { return this.get('/predictions'); }
  getNotifications() { return this.get('/notifications'); }
  getAuditLogs() { return this.get('/audit-logs'); }
  getReport(type, format = 'json', from, to) {
    const params = new URLSearchParams({ type, format });
    if (from) params.set('from', from);
    if (to) params.set('to', to);
    return this.get(`/reports?${params}`);
  }
  getOrganization() { return this.get('/organizations/me'); }
  changeOrgType(type) { return this.put('/organizations/me/type', { type }); }
}

export const api = new ApiClient();
export default api;
