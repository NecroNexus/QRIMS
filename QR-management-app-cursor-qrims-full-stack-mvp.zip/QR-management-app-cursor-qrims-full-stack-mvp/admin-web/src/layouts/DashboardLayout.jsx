import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Package, FolderTree, Building2, Users,
  Wrench, Clock, ArrowLeftRight, BarChart3, Brain, Settings,
  FileText, LogOut, QrCode, Bell,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const navItems = [
  { to: '/', icon: LayoutDashboard, label: 'Overview' },
  { to: '/inventory', icon: Package, label: 'Inventory' },
  { to: '/categories', icon: FolderTree, label: 'Categories' },
  { to: '/departments', icon: Building2, label: 'Departments' },
  { to: '/users', icon: Users, label: 'Users' },
  { to: '/maintenance', icon: Wrench, label: 'Maintenance' },
  { to: '/expiry', icon: Clock, label: 'Expiry' },
  { to: '/transactions', icon: ArrowLeftRight, label: 'Transactions' },
  { to: '/reports', icon: FileText, label: 'Reports' },
  { to: '/analytics', icon: BarChart3, label: 'Analytics' },
  { to: '/predictions', icon: Brain, label: 'AI Predictions' },
  { to: '/settings', icon: Settings, label: 'Settings' },
];

export default function DashboardLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="flex min-h-screen">
      <aside className="w-64 bg-slate-900 text-white flex flex-col shrink-0">
        <div className="p-6 border-b border-slate-700">
          <div className="flex items-center gap-2">
            <QrCode className="w-8 h-8 text-indigo-400" />
            <div>
              <h1 className="font-bold text-lg">QRIMS</h1>
              <p className="text-xs text-slate-400">Inventory Management</p>
            </div>
          </div>
        </div>
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map(({ to, icon: Icon, label }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                  isActive ? 'bg-indigo-600 text-white' : 'text-slate-300 hover:bg-slate-800'
                }`
              }
            >
              <Icon className="w-4 h-4" />
              {label}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t border-slate-700">
          <div className="text-sm mb-2">
            <p className="font-medium truncate">{user?.name}</p>
            <p className="text-xs text-slate-400 truncate">{user?.organization?.name}</p>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 text-sm text-slate-400 hover:text-white w-full px-3 py-2 rounded-lg hover:bg-slate-800"
          >
            <LogOut className="w-4 h-4" /> Sign out
          </button>
        </div>
      </aside>
      <main className="flex-1 overflow-auto">
        <header className="bg-white border-b border-slate-200 px-8 py-4 flex items-center justify-between sticky top-0 z-10">
          <h2 className="text-lg font-semibold text-slate-700">
            {user?.organization?.name || 'Dashboard'}
            <span className="ml-2 text-xs font-normal text-slate-400 capitalize">
              ({user?.organization?.type})
            </span>
          </h2>
          <button className="p-2 rounded-lg hover:bg-slate-100 relative">
            <Bell className="w-5 h-5 text-slate-500" />
          </button>
        </header>
        <div className="p-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
