const STATUS_COLORS = {
  available: 'bg-emerald-100 text-emerald-700',
  assigned: 'bg-blue-100 text-blue-700',
  in_use: 'bg-indigo-100 text-indigo-700',
  low_stock: 'bg-amber-100 text-amber-700',
  out_of_stock: 'bg-rose-100 text-rose-700',
  maintenance: 'bg-orange-100 text-orange-700',
  damaged: 'bg-red-100 text-red-700',
  lost: 'bg-slate-100 text-slate-700',
  disposed: 'bg-slate-100 text-slate-500',
};

export default function StatusBadge({ status }) {
  const cls = STATUS_COLORS[status] || 'bg-slate-100 text-slate-600';
  return (
    <span className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-medium capitalize ${cls}`}>
      {status?.replace(/_/g, ' ')}
    </span>
  );
}
