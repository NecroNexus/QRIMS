import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { QrCode } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const [email, setEmail] = useState('admin@abcuniversity.edu');
  const [password, setPassword] = useState('Demo@123');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(email, password);
      toast.success('Welcome back!');
      navigate('/');
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex">
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-indigo-600 to-slate-900 items-center justify-center p-12">
        <div className="text-white max-w-md">
          <QrCode className="w-16 h-16 mb-6 text-indigo-300" />
          <h1 className="text-4xl font-bold mb-4">QRIMS</h1>
          <p className="text-indigo-200 text-lg">
            Smart Multi-Domain Inventory Management with QR-powered tracking for any organization type.
          </p>
        </div>
      </div>
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          <h2 className="text-2xl font-bold mb-2">Sign in</h2>
          <p className="text-slate-500 mb-8">Access your organization dashboard</p>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                required
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 disabled:opacity-50 transition-colors"
            >
              {loading ? 'Signing in...' : 'Sign in'}
            </button>
          </form>
          <p className="mt-6 text-center text-sm text-slate-500">
            New organization?{' '}
            <button onClick={() => navigate('/onboarding')} className="text-indigo-600 font-medium hover:underline">
              Start onboarding
            </button>
          </p>
          <div className="mt-8 p-4 bg-slate-50 rounded-lg text-xs text-slate-500">
            <p className="font-medium mb-1">Demo credentials:</p>
            <p>admin@abcuniversity.edu / Demo@123</p>
            <p>admin@cityhospital.org / Demo@123</p>
          </div>
        </div>
      </div>
    </div>
  );
}
