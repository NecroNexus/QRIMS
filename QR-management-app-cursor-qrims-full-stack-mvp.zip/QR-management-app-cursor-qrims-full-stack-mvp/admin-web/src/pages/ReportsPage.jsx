import { useEffect, useState } from 'react';
import api from '../services/api';
import LoadingSpinner from '../components/LoadingSpinner';
import toast from 'react-hot-toast';

const REPORT_TYPES = [
  { id: 'inventory', label: 'Inventory Report' },
  { id: 'stock_movement', label: 'Stock Movement' },
  { id: 'low_stock', label: 'Low Stock' },
  { id: 'maintenance', label: 'Maintenance' },
  { id: 'expiry', label: 'Expiry' },
  { id: 'audit', label: 'User Activity' },
];

export default function ReportsPage() {
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(false);
  const [type, setType] = useState('inventory');

  const generate = async (format = 'json') => {
    setLoading(true);
    try {
      if (format === 'csv' || format === 'pdf') {
        window.open(`${import.meta.env.VITE_API_URL || '/api'}/reports?type=${type}&format=${format}`, '_blank');
        toast.success(`Downloading ${format.toUpperCase()} report`);
      } else {
        const d = await api.getReport(type);
        setReport(d.data);
      }
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Reports</h1>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {REPORT_TYPES.map((r) => (
          <button
            key={r.id}
            onClick={() => setType(r.id)}
            className={`p-4 rounded-xl border text-left ${type === r.id ? 'border-indigo-600 bg-indigo-50' : 'border-slate-200 bg-white hover:bg-slate-50'}`}
          >
            {r.label}
          </button>
        ))}
      </div>
      <div className="flex gap-2">
        <button onClick={() => generate('json')} disabled={loading} className="px-4 py-2 bg-indigo-600 text-white rounded-lg">Generate</button>
        <button onClick={() => generate('csv')} className="px-4 py-2 border rounded-lg">Export CSV</button>
        <button onClick={() => generate('pdf')} className="px-4 py-2 border rounded-lg">Export PDF</button>
      </div>
      {loading && <LoadingSpinner />}
      {report && (
        <div className="bg-white rounded-xl border p-6">
          <h3 className="font-semibold">{report.title}</h3>
          <p className="text-sm text-slate-500 mt-1">
            {report.meta?.organization} · {report.meta?.summary?.totalRecords} records
          </p>
          <pre className="mt-4 text-xs bg-slate-50 p-4 rounded-lg overflow-auto max-h-96">
            {JSON.stringify(report.data?.slice(0, 10), null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}
