import { useEffect, useState } from 'react';
import api from '../services/api';
import LoadingSpinner from '../components/LoadingSpinner';

export default function PredictionsPage() {
  const [predictions, setPredictions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getPredictions().then((d) => setPredictions(d.data.predictions)).finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingSpinner message="Calculating demand forecasts..." />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Demand Predictions</h1>
        <p className="text-slate-500">Statistical forecasting using moving averages and linear regression</p>
      </div>
      <div className="grid gap-4">
        {predictions.map((p) => (
          <div key={p.itemId} className="bg-white rounded-xl border p-6">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold">{p.itemName}</h3>
                {p.reorderRecommended && (
                  <span className="inline-block mt-1 px-2 py-0.5 bg-amber-100 text-amber-700 text-xs rounded-full font-medium">
                    Reorder Recommended
                  </span>
                )}
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold">{p.currentStock}</p>
                <p className="text-xs text-slate-500">Current Stock</p>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t">
              <div>
                <p className="text-xs text-slate-500">Avg Monthly Usage</p>
                <p className="font-semibold">{p.averageMonthlyUsage}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500">Predicted Next Month</p>
                <p className="font-semibold">{p.predictedNextMonth}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500">Recommended Reorder</p>
                <p className="font-semibold text-indigo-600">{p.recommendedReorderQuantity}</p>
              </div>
            </div>
            <ul className="mt-4 space-y-1">
              {p.explanation?.map((line, i) => (
                <li key={i} className="text-xs text-slate-500">• {line}</li>
              ))}
            </ul>
          </div>
        ))}
        {predictions.length === 0 && <p className="text-center py-12 text-slate-400">No prediction data available</p>}
      </div>
    </div>
  );
}
