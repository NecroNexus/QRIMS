import { useEffect, useState } from 'react';
import api from '../services/api';
import LoadingSpinner from '../components/LoadingSpinner';
import toast from 'react-hot-toast';

const ORG_TYPES = ['college', 'hospital', 'library', 'office', 'retail', 'warehouse', 'manufacturing', 'restaurant', 'custom'];

export default function SettingsPage() {
  const [org, setOrg] = useState(null);
  const [template, setTemplate] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.getOrganization(), api.getTemplate()])
      .then(([o, t]) => {
        setOrg(o.data.organization);
        setTemplate(t.data.template);
      })
      .finally(() => setLoading(false));
  }, []);

  const changeType = async (type) => {
    if (!confirm(`Change organization type to ${type}? This will update the inventory template.`)) return;
    try {
      await api.changeOrgType(type);
      toast.success('Organization type updated');
      const t = await api.getTemplate();
      setTemplate(t.data.template);
    } catch (err) {
      toast.error(err.message);
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold">Organization Settings</h1>

      <div className="bg-white rounded-xl border p-6">
        <h3 className="font-semibold mb-4">Organization Info</h3>
        <dl className="grid grid-cols-2 gap-4 text-sm">
          <div><dt className="text-slate-500">Name</dt><dd className="font-medium">{org?.name}</dd></div>
          <div><dt className="text-slate-500">Code</dt><dd className="font-mono">{org?.orgCode}</dd></div>
          <div><dt className="text-slate-500">Type</dt><dd className="capitalize">{org?.type}</dd></div>
        </dl>
      </div>

      <div className="bg-white rounded-xl border p-6">
        <h3 className="font-semibold mb-4">Change Organization Type</h3>
        <p className="text-sm text-slate-500 mb-4">Switch domain to see different inventory field templates</p>
        <div className="grid grid-cols-3 gap-2">
          {ORG_TYPES.map((type) => (
            <button
              key={type}
              onClick={() => changeType(type)}
              className={`p-3 rounded-lg border text-sm capitalize ${
                org?.type === type ? 'border-indigo-600 bg-indigo-50' : 'hover:bg-slate-50'
              }`}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl border p-6">
        <h3 className="font-semibold mb-4">Inventory Template Fields</h3>
        <div className="space-y-2">
          {template?.fields?.map((f) => (
            <div key={f.key} className="flex items-center justify-between py-2 border-b border-slate-100 text-sm">
              <span>{f.label}</span>
              <span className="text-slate-400 capitalize">{f.type}{f.required && ' · required'}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
