import { useEffect, useState } from 'react';
import { Plus, Search, QrCode } from 'lucide-react';
import api from '../services/api';
import LoadingSpinner, { EmptyState } from '../components/LoadingSpinner';
import StatusBadge from '../components/StatusBadge';
import toast from 'react-hot-toast';

export default function InventoryPage() {
  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [template, setTemplate] = useState(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [qrModal, setQrModal] = useState(null);
  const [form, setForm] = useState({ name: '', quantity: 1, cost: 0, category: '', customFields: {} });

  const load = () => {
    Promise.all([
      api.getInventory('limit=50'),
      api.getCategories(),
      api.getTemplate(),
    ]).then(([i, c, t]) => {
      setItems(i.data.items);
      setCategories(c.data.categories);
      setTemplate(t.data.template);
    }).finally(() => setLoading(false));
  };

  useEffect(load, []);

  const handleSearch = async () => {
    if (!search.trim()) return load();
    const d = await api.searchInventory(search);
    setItems(d.data.items);
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      const d = await api.createInventoryItem(form);
      toast.success('Item created with QR code');
      setShowModal(false);
      setQrModal(d.data.qrCodeDataUrl);
      load();
    } catch (err) {
      toast.error(err.message);
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Inventory</h1>
          <p className="text-slate-500">{items.length} items</p>
        </div>
        <button onClick={() => setShowModal(true)} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
          <Plus className="w-4 h-4" /> Add Item
        </button>
      </div>

      <div className="flex gap-2">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            placeholder="Search by name, QR ID..."
            className="w-full pl-10 pr-4 py-2 border rounded-lg"
          />
        </div>
        <button onClick={handleSearch} className="px-4 py-2 border rounded-lg hover:bg-slate-50">Search</button>
      </div>

      {items.length === 0 ? (
        <EmptyState title="No inventory items" description="Add your first item to generate a QR code" />
      ) : (
        <div className="bg-white rounded-xl border overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50">
              <tr>
                <th className="text-left px-6 py-3 font-medium text-slate-500">Item</th>
                <th className="text-left px-6 py-3 font-medium text-slate-500">QR ID</th>
                <th className="text-left px-6 py-3 font-medium text-slate-500">Category</th>
                <th className="text-left px-6 py-3 font-medium text-slate-500">Qty</th>
                <th className="text-left px-6 py-3 font-medium text-slate-500">Status</th>
                <th className="text-left px-6 py-3 font-medium text-slate-500">Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((item) => (
                <tr key={item._id} className="border-t hover:bg-slate-50">
                  <td className="px-6 py-3 font-medium">{item.name}</td>
                  <td className="px-6 py-3 font-mono text-xs">{item.qrId}</td>
                  <td className="px-6 py-3">{item.category?.name || '—'}</td>
                  <td className="px-6 py-3">{item.quantity}</td>
                  <td className="px-6 py-3"><StatusBadge status={item.status} /></td>
                  <td className="px-6 py-3">
                    <button
                      onClick={async () => {
                        const d = await api.getQr(item._id);
                        setQrModal(d.data.qrCodeDataUrl);
                      }}
                      className="text-indigo-600 hover:underline flex items-center gap-1"
                    >
                      <QrCode className="w-4 h-4" /> QR
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <form onSubmit={handleCreate} className="bg-white rounded-xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-bold mb-4">Add Inventory Item</h3>
            <div className="space-y-3">
              <input required placeholder="Item name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full px-3 py-2 border rounded-lg" />
              <div className="grid grid-cols-2 gap-3">
                <input type="number" placeholder="Quantity" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })} className="px-3 py-2 border rounded-lg" />
                <input type="number" placeholder="Cost" value={form.cost} onChange={(e) => setForm({ ...form, cost: Number(e.target.value) })} className="px-3 py-2 border rounded-lg" />
              </div>
              <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="w-full px-3 py-2 border rounded-lg">
                <option value="">Select category</option>
                {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
              </select>
              {template?.fields?.map((field) => (
                <div key={field.key}>
                  <label className="text-xs text-slate-500">{field.label}{field.required && ' *'}</label>
                  {field.type === 'dropdown' ? (
                    <select
                      value={form.customFields[field.key] || ''}
                      onChange={(e) => setForm({ ...form, customFields: { ...form.customFields, [field.key]: e.target.value } })}
                      className="w-full px-3 py-2 border rounded-lg"
                    >
                      <option value="">Select</option>
                      {field.options?.map((o) => <option key={o} value={o}>{o}</option>)}
                    </select>
                  ) : (
                    <input
                      type={field.type === 'number' || field.type === 'currency' ? 'number' : field.type === 'date' ? 'date' : 'text'}
                      value={form.customFields[field.key] || ''}
                      onChange={(e) => setForm({ ...form, customFields: { ...form.customFields, [field.key]: e.target.value } })}
                      className="w-full px-3 py-2 border rounded-lg"
                    />
                  )}
                </div>
              ))}
            </div>
            <div className="flex gap-2 mt-6">
              <button type="button" onClick={() => setShowModal(false)} className="flex-1 py-2 border rounded-lg">Cancel</button>
              <button type="submit" className="flex-1 py-2 bg-indigo-600 text-white rounded-lg">Create</button>
            </div>
          </form>
        </div>
      )}

      {qrModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setQrModal(null)}>
          <div className="bg-white rounded-xl p-6 text-center" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-bold mb-4">QR Code Generated</h3>
            <img src={qrModal} alt="QR Code" className="mx-auto w-64 h-64" />
            <button onClick={() => setQrModal(null)} className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-lg">Close</button>
          </div>
        </div>
      )}
    </div>
  );
}
