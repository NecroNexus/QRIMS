import { useEffect, useState } from 'react';
import api from '../services/api';
import LoadingSpinner from '../components/LoadingSpinner';
import StatusBadge from '../components/StatusBadge';
import toast from 'react-hot-toast';

export default function MaintenancePage() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getMaintenance().then((d) => setRequests(d.data.requests)).finally(() => setLoading(false));
  }, []);

  const updateStatus = async (id, status) => {
    try {
      await api.updateMaintenance(id, { status });
      toast.success(`Status updated to ${status}`);
      const d = await api.getMaintenance();
      setRequests(d.data.requests);
    } catch (err) {
      toast.error(err.message);
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Maintenance Requests</h1>
      <div className="bg-white rounded-xl border overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50">
            <tr>
              <th className="text-left px-6 py-3">Item</th>
              <th className="text-left px-6 py-3">Problem</th>
              <th className="text-left px-6 py-3">Priority</th>
              <th className="text-left px-6 py-3">Status</th>
              <th className="text-left px-6 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {requests.map((r) => (
              <tr key={r._id} className="border-t">
                <td className="px-6 py-3">{r.item?.name}</td>
                <td className="px-6 py-3">{r.problem}</td>
                <td className="px-6 py-3 capitalize">{r.priority}</td>
                <td className="px-6 py-3"><StatusBadge status={r.status} /></td>
                <td className="px-6 py-3 space-x-2">
                  {r.status === 'requested' && (
                    <button onClick={() => updateStatus(r._id, 'approved')} className="text-emerald-600 text-xs font-medium">Approve</button>
                  )}
                  {r.status === 'approved' && (
                    <button onClick={() => updateStatus(r._id, 'in_progress')} className="text-indigo-600 text-xs font-medium">Start</button>
                  )}
                  {r.status === 'in_progress' && (
                    <button onClick={() => updateStatus(r._id, 'completed')} className="text-emerald-600 text-xs font-medium">Complete</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {requests.length === 0 && <p className="text-center py-12 text-slate-400">No maintenance requests</p>}
      </div>
    </div>
  );
}
