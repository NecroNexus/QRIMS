import { useEffect, useState } from 'react';
import { Package, DollarSign, AlertTriangle, Wrench, Clock } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import api from '../services/api';
import StatCard from '../components/StatCard';
import LoadingSpinner from '../components/LoadingSpinner';
import StatusBadge from '../components/StatusBadge';

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];

export default function OverviewPage() {
  const [analytics, setAnalytics] = useState(null);
  const [recentItems, setRecentItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.getAnalytics(),
      api.getInventory('limit=5&sort=-updatedAt'),
    ]).then(([a, i]) => {
      setAnalytics(a.data.analytics);
      setRecentItems(i.data.items);
    }).catch(console.error).finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingSpinner />;

  const a = analytics || {};
  const categoryData = (a.categoryBreakdown || []).map((c) => ({
    name: c.name || 'Uncategorized',
    value: c.count,
  }));

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold">Overview</h1>
        <p className="text-slate-500">Real-time inventory snapshot</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <StatCard title="Total Items" value={a.totalItems || 0} icon={Package} />
        <StatCard title="Total Value" value={`$${(a.totalValue || 0).toLocaleString()}`} icon={DollarSign} color="emerald" />
        <StatCard title="Low Stock" value={a.lowStock || 0} icon={AlertTriangle} color="amber" />
        <StatCard title="Maintenance" value={a.underMaintenance || 0} icon={Wrench} color="rose" />
        <StatCard title="Expiring Soon" value={a.expiringSoon || 0} icon={Clock} color="sky" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h3 className="font-semibold mb-4">Inventory by Category</h3>
          {categoryData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie data={categoryData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                  {categoryData.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-slate-400 text-center py-12">No data yet</p>
          )}
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h3 className="font-semibold mb-4">Stock Movement (6 months)</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={(a.monthlyMovement || []).slice(0, 12)}>
              <XAxis dataKey="_id.month" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="total" fill="#6366f1" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200">
          <h3 className="font-semibold">Recently Updated Items</h3>
        </div>
        <table className="w-full text-sm">
          <thead className="bg-slate-50">
            <tr>
              <th className="text-left px-6 py-3 font-medium text-slate-500">Name</th>
              <th className="text-left px-6 py-3 font-medium text-slate-500">QR ID</th>
              <th className="text-left px-6 py-3 font-medium text-slate-500">Qty</th>
              <th className="text-left px-6 py-3 font-medium text-slate-500">Status</th>
            </tr>
          </thead>
          <tbody>
            {recentItems.map((item) => (
              <tr key={item._id} className="border-t border-slate-100 hover:bg-slate-50">
                <td className="px-6 py-3 font-medium">{item.name}</td>
                <td className="px-6 py-3 font-mono text-xs text-slate-500">{item.qrId}</td>
                <td className="px-6 py-3">{item.quantity} {item.unit}</td>
                <td className="px-6 py-3"><StatusBadge status={item.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
