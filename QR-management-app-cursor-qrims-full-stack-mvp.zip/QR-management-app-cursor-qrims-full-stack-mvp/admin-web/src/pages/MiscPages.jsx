import { useEffect, useState } from 'react';
import api from '../services/api';
import LoadingSpinner from '../components/LoadingSpinner';

function SimpleListPage({ title, fetchFn, labelKey = 'name' }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFn().then((d) => {
      const key = Object.keys(d.data)[0];
      setItems(d.data[key]);
    }).finally(() => setLoading(false));
  }, [fetchFn]);

  if (loading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">{title}</h1>
      <div className="grid gap-3">
        {items.map((item) => (
          <div key={item._id} className="bg-white rounded-xl border p-4 flex items-center justify-between">
            <span className="font-medium">{item[labelKey]}</span>
            {item.description && <span className="text-sm text-slate-500">{item.description}</span>}
          </div>
        ))}
        {items.length === 0 && <p className="text-center py-12 text-slate-400">No items found</p>}
      </div>
    </div>
  );
}

export const CategoriesPage = () => <SimpleListPage title="Categories" fetchFn={() => api.getCategories()} />;
export const DepartmentsPage = () => <SimpleListPage title="Departments" fetchFn={() => api.getDepartments()} />;
export const UsersPage = () => <SimpleListPage title="Users" fetchFn={() => api.getUsers()} labelKey="email" />;

export function ExpiryPage() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getExpiring(30).then((d) => setItems(d.data.items)).finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Expiring Items (30 days)</h1>
      <div className="grid gap-3">
        {items.map((item) => {
          const days = Math.ceil((new Date(item.expiryDate) - new Date()) / 86400000);
          return (
            <div key={item._id} className="bg-white rounded-xl border p-4 flex justify-between">
              <span className="font-medium">{item.name}</span>
              <span className={`text-sm ${days <= 7 ? 'text-rose-600' : 'text-amber-600'}`}>
                {days} days remaining
              </span>
            </div>
          );
        })}
        {items.length === 0 && <p className="text-center py-12 text-slate-400">No expiring items</p>}
      </div>
    </div>
  );
}

export function AnalyticsPage() {
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getAnalytics().then((d) => setAnalytics(d.data.analytics)).finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Analytics</h1>
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-xl border p-6">
          <h3 className="font-semibold mb-4">By Status</h3>
          {(analytics?.statusBreakdown || []).map((s) => (
            <div key={s._id} className="flex justify-between py-2 border-b text-sm">
              <span className="capitalize">{s._id?.replace(/_/g, ' ')}</span>
              <span className="font-medium">{s.count}</span>
            </div>
          ))}
        </div>
        <div className="bg-white rounded-xl border p-6">
          <h3 className="font-semibold mb-4">Most Used Items</h3>
          {(analytics?.mostUsedItems || []).map((item, i) => (
            <div key={i} className="flex justify-between py-2 border-b text-sm">
              <span>{item.name}</span>
              <span className="font-medium">{item.totalUsed} used</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function TransactionsPage() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getInventory('limit=5').then(async (d) => {
      if (d.data.items[0]) {
        const tx = await api.getTransactions(d.data.items[0]._id);
        setItems(tx.data.transactions);
      }
    }).finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Recent Transactions</h1>
      <div className="bg-white rounded-xl border overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50">
            <tr>
              <th className="text-left px-6 py-3">Type</th>
              <th className="text-left px-6 py-3">Quantity</th>
              <th className="text-left px-6 py-3">By</th>
              <th className="text-left px-6 py-3">Date</th>
            </tr>
          </thead>
          <tbody>
            {items.map((tx) => (
              <tr key={tx._id} className="border-t">
                <td className="px-6 py-3 capitalize">{tx.type?.replace(/_/g, ' ')}</td>
                <td className="px-6 py-3">{tx.quantity}</td>
                <td className="px-6 py-3">{tx.performedBy?.name}</td>
                <td className="px-6 py-3">{new Date(tx.createdAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {items.length === 0 && <p className="text-center py-12 text-slate-400">No transactions yet</p>}
      </div>
    </div>
  );
}
