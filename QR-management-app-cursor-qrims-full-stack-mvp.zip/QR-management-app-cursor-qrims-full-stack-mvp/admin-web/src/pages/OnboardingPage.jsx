import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import toast from 'react-hot-toast';

const ORG_TYPES = [
  'college', 'hospital', 'library', 'office', 'retail',
  'warehouse', 'manufacturing', 'restaurant', 'custom',
];

export default function OnboardingPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    organizationName: '',
    organizationType: 'college',
    departments: ['Main Department'],
    adminName: '',
    adminEmail: '',
    adminPassword: '',
  });

  const update = (key, value) => setForm((f) => ({ ...f, [key]: value }));

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const d = await api.onboarding({
        ...form,
        departments: form.departments.filter(Boolean).map((name) => ({ name })),
      });
      toast.success(`Organization ${d.data.organization.orgCode} created!`);
      navigate('/');
      window.location.reload();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-8">
      <div className="w-full max-w-lg bg-white rounded-2xl shadow-lg border border-slate-200 p-8">
        <h1 className="text-2xl font-bold mb-2">Organization Setup</h1>
        <p className="text-slate-500 mb-6">Step {step} of 5</p>

        <div className="flex gap-2 mb-8">
          {[1, 2, 3, 4, 5].map((s) => (
            <div key={s} className={`h-1 flex-1 rounded ${s <= step ? 'bg-indigo-600' : 'bg-slate-200'}`} />
          ))}
        </div>

        {step === 1 && (
          <div>
            <label className="block text-sm font-medium mb-1">Organization Name</label>
            <input
              value={form.organizationName}
              onChange={(e) => update('organizationName', e.target.value)}
              className="w-full px-4 py-2.5 border rounded-lg mb-4"
              placeholder="ABC University"
            />
          </div>
        )}

        {step === 2 && (
          <div>
            <label className="block text-sm font-medium mb-2">Organization Type</label>
            <div className="grid grid-cols-3 gap-2">
              {ORG_TYPES.map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => update('organizationType', type)}
                  className={`p-3 rounded-lg border text-sm capitalize ${
                    form.organizationType === type ? 'border-indigo-600 bg-indigo-50 text-indigo-700' : 'border-slate-200'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 3 && (
          <div>
            <label className="block text-sm font-medium mb-2">Departments</label>
            {form.departments.map((dept, i) => (
              <input
                key={i}
                value={dept}
                onChange={(e) => {
                  const deps = [...form.departments];
                  deps[i] = e.target.value;
                  update('departments', deps);
                }}
                className="w-full px-4 py-2.5 border rounded-lg mb-2"
                placeholder={`Department ${i + 1}`}
              />
            ))}
            <button
              type="button"
              onClick={() => update('departments', [...form.departments, ''])}
              className="text-sm text-indigo-600"
            >
              + Add department
            </button>
          </div>
        )}

        {step === 4 && (
          <div className="text-center py-8">
            <p className="text-slate-600">
              Inventory template for <strong className="capitalize">{form.organizationType}</strong> will be auto-configured with domain-specific fields and categories.
            </p>
          </div>
        )}

        {step === 5 && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Admin Name</label>
              <input value={form.adminName} onChange={(e) => update('adminName', e.target.value)} className="w-full px-4 py-2.5 border rounded-lg" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Admin Email</label>
              <input type="email" value={form.adminEmail} onChange={(e) => update('adminEmail', e.target.value)} className="w-full px-4 py-2.5 border rounded-lg" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Password</label>
              <input type="password" value={form.adminPassword} onChange={(e) => update('adminPassword', e.target.value)} className="w-full px-4 py-2.5 border rounded-lg" />
            </div>
          </div>
        )}

        <div className="flex justify-between mt-8">
          <button
            type="button"
            onClick={() => (step > 1 ? setStep(step - 1) : navigate('/login'))}
            className="px-4 py-2 text-slate-600 hover:text-slate-900"
          >
            {step === 1 ? 'Back to login' : 'Previous'}
          </button>
          {step < 5 ? (
            <button
              type="button"
              onClick={() => setStep(step + 1)}
              className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
            >
              Next
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSubmit}
              disabled={loading}
              className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50"
            >
              {loading ? 'Creating...' : 'Complete Setup'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
