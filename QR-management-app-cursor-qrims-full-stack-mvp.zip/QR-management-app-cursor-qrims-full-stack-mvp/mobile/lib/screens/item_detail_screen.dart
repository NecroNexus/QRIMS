import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mobile/providers/auth_provider.dart';

class ItemDetailScreen extends StatefulWidget {
  final Map<String, dynamic> scanData;
  const ItemDetailScreen({super.key, required this.scanData});

  @override
  State<ItemDetailScreen> createState() => _ItemDetailScreenState();
}

class _ItemDetailScreenState extends State<ItemDetailScreen> {
  late Map<String, dynamic> _item;
  List<dynamic> _transactions = [];
  List<dynamic> _maintenance = [];

  @override
  void initState() {
    super.initState();
    _item = widget.scanData['item'] as Map<String, dynamic>;
    _transactions = widget.scanData['transactions'] as List<dynamic>? ?? [];
    _maintenance = widget.scanData['maintenance'] as List<dynamic>? ?? [];
  }

  Future<void> _stockOp(String type) async {
    final qtyController = TextEditingController(text: '1');
    final reasonController = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(type == 'in' ? 'Stock In' : 'Stock Out'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: qtyController, decoration: const InputDecoration(labelText: 'Quantity'), keyboardType: TextInputType.number),
            if (type == 'out')
              TextField(controller: reasonController, decoration: const InputDecoration(labelText: 'Reason')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Confirm')),
        ],
      ),
    );
    if (ok != true) return;

    final api = context.read<AuthProvider>().api;
    final qty = double.tryParse(qtyController.text) ?? 1;
    try {
      final result = type == 'in'
          ? await api.stockIn(_item['_id'], qty)
          : await api.stockOut(_item['_id'], qty, reason: reasonController.text);
      if (!mounted) return;
      setState(() => _item = result['item'] as Map<String, dynamic>);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Stock updated')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()), backgroundColor: Colors.red));
    }
  }

  Future<void> _maintenanceRequest() async {
    final problem = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Maintenance Request'),
        content: TextField(controller: problem, decoration: const InputDecoration(labelText: 'Problem description')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Submit')),
        ],
      ),
    );
    if (ok != true || problem.text.isEmpty) return;
    try {
      await context.read<AuthProvider>().api.createMaintenance(_item['_id'], problem.text);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Maintenance request submitted')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()), backgroundColor: Colors.red));
    }
  }

  @override
  Widget build(BuildContext context) {
    final customFields = _item['customFields'] as Map<String, dynamic>? ?? {};

    return Scaffold(
      appBar: AppBar(title: Text(_item['name'] ?? 'Item Details')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (_item['imageUrl'] != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.network(_item['imageUrl'], height: 180, fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(height: 120, color: Colors.grey.shade200, child: const Icon(Icons.image, size: 48)),
                ),
              )
            else
              Container(
                height: 120,
                decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(16)),
                child: const Icon(Icons.inventory_2, size: 48, color: Colors.grey),
              ),
            const SizedBox(height: 16),
            _InfoRow('QR ID', _item['qrId'] ?? ''),
            _InfoRow('Quantity', '${_item['quantity']} ${_item['unit'] ?? 'units'}'),
            _InfoRow('Status', (_item['status'] ?? '').toString().replaceAll('_', ' ')),
            _InfoRow('Location', _item['location']?['name'] ?? '—'),
            _InfoRow('Department', _item['department']?['name'] ?? '—'),
            if (_item['assignedTo'] != null)
              _InfoRow('Assigned To', _item['assignedTo']['name'] ?? ''),
            if (_item['warrantyExpiry'] != null)
              _InfoRow('Warranty', _item['warrantyExpiry'].toString().split('T').first),
            ...customFields.entries.map((e) => _InfoRow(e.key, e.value.toString())),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(child: FilledButton.icon(onPressed: () => _stockOp('in'), icon: const Icon(Icons.add), label: const Text('Stock In'))),
                const SizedBox(width: 8),
                Expanded(child: OutlinedButton.icon(onPressed: () => _stockOp('out'), icon: const Icon(Icons.remove), label: const Text('Stock Out'))),
              ],
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _maintenanceRequest,
              icon: const Icon(Icons.build),
              label: const Text('Request Maintenance'),
            ),
            const SizedBox(height: 24),
            Text('Recent Transactions', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            ..._transactions.take(5).map((tx) {
              final t = tx as Map<String, dynamic>;
              return ListTile(
                dense: true,
                leading: Icon(t['type'] == 'stock_in' ? Icons.arrow_downward : Icons.arrow_upward),
                title: Text('${t['type']?.toString().replaceAll('_', ' ')} · ${t['quantity']}'),
                subtitle: Text(t['performedBy']?['name'] ?? ''),
              );
            }),
            if (_maintenance.isNotEmpty) ...[
              const SizedBox(height: 16),
              Text('Maintenance History', style: Theme.of(context).textTheme.titleMedium),
              ..._maintenance.map((m) {
                final r = m as Map<String, dynamic>;
                return ListTile(
                  dense: true,
                  title: Text(r['problem'] ?? ''),
                  subtitle: Text(r['status'] ?? ''),
                );
              }),
            ],
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 120, child: Text(label, style: TextStyle(color: Colors.grey.shade600, fontSize: 13))),
          Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w500))),
        ],
      ),
    );
  }
}
