import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mobile/providers/auth_provider.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  List<dynamic> _notifications = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final items = await context.read<AuthProvider>().api.getNotifications();
      setState(() { _notifications = items; _loading = false; });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());

    if (_notifications.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.notifications_none, size: 64, color: Colors.grey.shade400),
            const SizedBox(height: 16),
            Text('No notifications', style: TextStyle(color: Colors.grey.shade600)),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _notifications.length,
        itemBuilder: (_, i) {
          final n = _notifications[i] as Map<String, dynamic>;
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: Icon(
                _iconForType(n['type']),
                color: n['isRead'] == true ? Colors.grey : Theme.of(context).colorScheme.primary,
              ),
              title: Text(n['title'] ?? '', style: TextStyle(fontWeight: n['isRead'] == true ? FontWeight.normal : FontWeight.bold)),
              subtitle: Text(n['message'] ?? ''),
            ),
          );
        },
      ),
    );
  }

  IconData _iconForType(String? type) {
    switch (type) {
      case 'low_stock':
      case 'out_of_stock':
        return Icons.warning;
      case 'expiring':
        return Icons.schedule;
      case 'maintenance_due':
        return Icons.build;
      case 'assignment':
        return Icons.person;
      default:
        return Icons.notifications;
    }
  }
}
