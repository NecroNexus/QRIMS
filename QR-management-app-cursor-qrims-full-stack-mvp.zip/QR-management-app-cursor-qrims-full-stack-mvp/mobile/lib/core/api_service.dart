import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  static String get _defaultBaseUrl {
    if (kIsWeb) return 'http://localhost:5001/api';
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return 'http://10.0.2.2:5001/api';
      default:
        return 'http://localhost:5001/api';
    }
  }

  static String get baseUrl {
    const fromEnv = String.fromEnvironment('API_URL');
    return fromEnv.isNotEmpty ? fromEnv : _defaultBaseUrl;
  }

  String? _token;

  Future<void> loadToken() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('qrims_token');
  }

  Future<void> saveToken(String? token) async {
    _token = token;
    final prefs = await SharedPreferences.getInstance();
    if (token != null) {
      await prefs.setString('qrims_token', token);
    } else {
      await prefs.remove('qrims_token');
    }
  }

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (_token != null) 'Authorization': 'Bearer $_token',
      };

  Future<Map<String, dynamic>> _request(
    String method,
    String path, {
    Map<String, dynamic>? body,
  }) async {
    final uri = Uri.parse('$baseUrl$path');
    http.Response response;

    switch (method) {
      case 'GET':
        response = await http.get(uri, headers: _headers);
        break;
      case 'POST':
        response = await http.post(uri, headers: _headers, body: jsonEncode(body));
        break;
      case 'PUT':
        response = await http.put(uri, headers: _headers, body: jsonEncode(body));
        break;
      default:
        throw Exception('Unsupported method');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode >= 400) {
      throw Exception(data['message'] ?? 'Request failed');
    }
    return data;
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    final data = await _request('POST', '/auth/login', body: {
      'email': email,
      'password': password,
    });
    await saveToken(data['data']['token'] as String);
    return data['data']['user'] as Map<String, dynamic>;
  }

  Future<void> logout() => saveToken(null);

  Future<Map<String, dynamic>> getMe() async {
    final data = await _request('GET', '/auth/me');
    return data['data']['user'] as Map<String, dynamic>;
  }

  Future<List<dynamic>> getInventory({String search = ''}) async {
    final path = search.isNotEmpty
        ? '/inventory/search?q=${Uri.encodeComponent(search)}'
        : '/inventory?limit=50';
    final data = await _request('GET', path);
    return data['data']['items'] as List<dynamic>;
  }

  Future<Map<String, dynamic>> scanQr(String qrId) async {
    final data = await _request('GET', '/inventory/scan/${Uri.encodeComponent(qrId)}');
    return data['data'] as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> stockIn(String itemId, double quantity, {String? reference}) async {
    final data = await _request('POST', '/inventory/$itemId/stock-in', body: {
      'quantity': quantity,
      if (reference != null) 'referenceNumber': reference,
    });
    return data['data'] as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> stockOut(String itemId, double quantity, {String? reason}) async {
    final data = await _request('POST', '/inventory/$itemId/stock-out', body: {
      'quantity': quantity,
      if (reason != null) 'reason': reason,
    });
    return data['data'] as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> createMaintenance(String itemId, String problem, {String? description}) async {
    final data = await _request('POST', '/maintenance', body: {
      'item': itemId,
      'problem': problem,
      if (description != null) 'description': description,
    });
    return data['data'] as Map<String, dynamic>;
  }

  Future<List<dynamic>> getNotifications() async {
    final data = await _request('GET', '/notifications');
    return data['data']['notifications'] as List<dynamic>;
  }
}
