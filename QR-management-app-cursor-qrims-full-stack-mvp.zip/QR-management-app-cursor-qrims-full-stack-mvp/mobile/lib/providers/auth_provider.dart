import 'package:flutter/foundation.dart';
import 'package:mobile/core/api_service.dart';

class AuthProvider extends ChangeNotifier {
  final ApiService api = ApiService();
  Map<String, dynamic>? user;
  bool loading = true;
  String? error;

  AuthProvider() {
    _init();
  }

  Future<void> _init() async {
    await api.loadToken();
    try {
      user = await api.getMe();
    } catch (_) {
      user = null;
    }
    loading = false;
    notifyListeners();
  }

  bool get isAuthenticated => user != null;

  Future<bool> login(String email, String password) async {
    error = null;
    try {
      user = await api.login(email, password);
      notifyListeners();
      return true;
    } catch (e) {
      error = e.toString().replaceFirst('Exception: ', '');
      notifyListeners();
      return false;
    }
  }

  Future<void> logout() async {
    await api.logout();
    user = null;
    notifyListeners();
  }
}
