package com.qrims.mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
