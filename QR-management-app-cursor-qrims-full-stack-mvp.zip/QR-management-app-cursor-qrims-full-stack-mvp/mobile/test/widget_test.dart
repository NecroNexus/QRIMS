import 'package:flutter_test/flutter_test.dart';
import 'package:mobile/main.dart';

void main() {
  testWidgets('QRIMS app smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(const QRIMSApp());
    expect(find.text('QRIMS'), findsOneWidget);
  });
}
