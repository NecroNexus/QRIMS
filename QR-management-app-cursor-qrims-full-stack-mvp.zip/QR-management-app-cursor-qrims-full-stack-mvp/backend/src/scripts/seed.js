import dotenv from 'dotenv';
import connectDB from '../config/db.js';
import User from '../models/User.js';
import Organization from '../models/Organization.js';
import Department from '../models/Department.js';
import Category from '../models/Category.js';
import InventoryItem from '../models/InventoryItem.js';
import Supplier from '../models/Supplier.js';
import { generateOrgCode, generateQrId } from '../utils/helpers.js';
import { createDefaultTemplate } from '../services/templateService.js';
import { ROLES } from '../config/constants.js';

dotenv.config();

const DEMO_ORGS = [
  {
    name: 'ABC University',
    type: 'college',
    admin: { name: 'Dr. Sarah Chen', email: 'admin@abcuniversity.edu', password: 'Demo@123' },
    departments: ['Computer Science', 'Physics Lab', 'IT Services', 'Administration'],
    items: [
      { name: 'Dell Laptop XPS 15', category: 'Electronics', quantity: 25, cost: 1200, unit: 'units', custom: { assetId: 'CS-LAP-001', condition: 'Good', lab: 'CS Lab A' } },
      { name: 'Epson Projector EB-X06', category: 'Electronics', quantity: 8, cost: 450, custom: { assetId: 'PHY-PRJ-002', condition: 'Good', lab: 'Physics Hall' } },
      { name: 'Logitech Keyboard K380', category: 'Electronics', quantity: 40, cost: 35, custom: { assetId: 'IT-KB-003', condition: 'New' } },
      { name: 'Cisco Router RV340', category: 'Networking', quantity: 5, cost: 280, custom: { assetId: 'NET-RTR-004', condition: 'Good' } },
    ],
  },
  {
    name: 'City Hospital',
    type: 'hospital',
    admin: { name: 'Dr. James Wilson', email: 'admin@cityhospital.org', password: 'Demo@123' },
    departments: ['Emergency', 'ICU', 'Radiology', 'Pharmacy'],
    items: [
      { name: 'ECG Machine GE MAC 2000', category: 'Medical Equipment', quantity: 3, cost: 8500, custom: { equipmentId: 'ECG-001', serialNumber: 'GE-2024-001', equipmentStatus: 'Operational' } },
      { name: 'Standard Wheelchair', category: 'Mobility', quantity: 20, cost: 350, custom: { equipmentId: 'WC-002', serialNumber: 'KM-WC-500' } },
      { name: 'Patient Monitor Mindray', category: 'Monitoring', quantity: 6, cost: 4200, custom: { equipmentId: 'MON-003', serialNumber: 'MD-PM-100' } },
      { name: 'Surgical Gloves (Box)', category: 'Supplies', quantity: 200, cost: 12, expiryDays: 180, custom: { equipmentId: 'SUP-004' } },
    ],
  },
  {
    name: 'Central Library',
    type: 'library',
    admin: { name: 'Maria Garcia', email: 'admin@centrallibrary.org', password: 'Demo@123' },
    departments: ['Reference', 'Digital Media', 'Archives', 'Circulation'],
    items: [
      { name: 'Clean Code by Robert Martin', category: 'Books', quantity: 5, cost: 35, custom: { bookId: 'BK-001', author: 'Robert C. Martin', rackNumber: 'A-12', availability: 'Available' } },
      { name: 'Design Patterns', category: 'Books', quantity: 3, cost: 45, custom: { bookId: 'BK-002', author: 'Gang of Four', rackNumber: 'A-13', availability: 'Available' } },
      { name: 'Library Computer Station', category: 'Computers', quantity: 15, cost: 800, custom: { bookId: 'PC-001', rackNumber: 'Digital-1', availability: 'Available' } },
      { name: 'BenQ Projector MH535', category: 'AV Equipment', quantity: 2, cost: 550, custom: { bookId: 'AV-001', rackNumber: 'Media-2', availability: 'Available' } },
    ],
  },
  {
    name: 'Tech Warehouse',
    type: 'warehouse',
    admin: { name: 'Mike Thompson', email: 'admin@techwarehouse.com', password: 'Demo@123' },
    departments: ['Receiving', 'Storage A', 'Storage B', 'Shipping'],
    items: [
      { name: 'Samsung SSD 1TB', category: 'Electronics', quantity: 150, cost: 89, reorderPoint: 30, custom: { sku: 'SSD-1TB-SAM', binLocation: 'A-01-03' } },
      { name: 'Cardboard Boxes (Large)', category: 'Packaging', quantity: 500, cost: 2.5, reorderPoint: 100, custom: { sku: 'BOX-LG-001', binLocation: 'B-02-01' } },
      { name: 'Resistor Kit 500pc', category: 'Components', quantity: 80, cost: 15, reorderPoint: 20, custom: { sku: 'RES-KIT-500', binLocation: 'C-01-05' } },
      { name: 'USB-C Cable 2m', category: 'Electronics', quantity: 300, cost: 8, reorderPoint: 50, custom: { sku: 'USB-C-2M', binLocation: 'A-03-02' } },
    ],
  },
];

const seed = async () => {
  await connectDB();
  console.log('Clearing existing data...');
  await Promise.all([
    User.deleteMany({}),
    Organization.deleteMany({}),
    Department.deleteMany({}),
    Category.deleteMany({}),
    InventoryItem.deleteMany({}),
    Supplier.deleteMany({}),
  ]);

  await User.create({
    name: 'Super Admin',
    email: 'superadmin@qrims.io',
    password: 'Super@123',
    role: ROLES.SUPER_ADMIN,
  });

  for (const demo of DEMO_ORGS) {
    const orgCode = generateOrgCode();
    const org = await Organization.create({
      name: demo.name,
      orgCode,
      type: demo.type,
      onboardingComplete: true,
    });

    await createDefaultTemplate(org._id, demo.type);
    const categories = await Category.find({ organization: org._id });
    const catMap = Object.fromEntries(categories.map((c) => [c.name, c._id]));

    const depts = [];
    for (const name of demo.departments) {
      depts.push(await Department.create({ name, organization: org._id }));
    }

    const admin = await User.create({
      ...demo.admin,
      role: ROLES.ORG_ADMIN,
      organization: org._id,
      department: depts[0]._id,
    });

    const staff = await User.create({
      name: 'Demo Staff',
      email: `staff@${demo.admin.email.split('@')[1]}`,
      password: 'Demo@123',
      role: ROLES.STAFF,
      organization: org._id,
      department: depts[0]._id,
    });

    const supplier = await Supplier.create({
      name: 'Primary Supplier Co.',
      organization: org._id,
      email: 'orders@supplier.com',
      leadTimeDays: 7,
    });

    for (const itemData of demo.items) {
      const qrId = generateQrId(orgCode);
      const expiryDate = itemData.expiryDays
        ? new Date(Date.now() + itemData.expiryDays * 86400000)
        : undefined;

      await InventoryItem.create({
        organization: org._id,
        qrId,
        name: itemData.name,
        category: catMap[itemData.category],
        quantity: itemData.quantity,
        unit: itemData.unit || 'units',
        cost: itemData.cost,
        department: depts[0]._id,
        supplier: supplier._id,
        expiryDate,
        customFields: itemData.custom || {},
        reorderConfig: {
          minStock: 5,
          maxStock: 200,
          reorderPoint: itemData.reorderPoint || 10,
          preferredSupplier: supplier._id,
          leadTimeDays: 7,
        },
        createdBy: admin._id,
        status: itemData.quantity > (itemData.reorderPoint || 10) ? 'available' : 'low_stock',
        lifecycleHistory: [{ event: 'purchased', performedBy: admin._id, note: 'Seed data' }],
      });
    }

    console.log(`Seeded: ${demo.name} (${orgCode}) - Admin: ${demo.admin.email}`);
  }

  console.log('\nDemo credentials:');
  console.log('Super Admin: superadmin@qrims.io / Super@123');
  console.log('Org Admins: admin@<domain> / Demo@123');
  console.log('Staff: staff@<domain> / Demo@123');
  process.exit(0);
};

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
