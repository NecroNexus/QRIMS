import { Router } from 'express';
import { getAnalytics } from '../controllers/analyticsController.js';
import { generateReport } from '../controllers/reportController.js';
import {
  listUsers,
  updateUser,
  crudDepartment,
  crudCategory,
  crudLocation,
  getTemplate,
  updateTemplate,
  listNotifications,
  markNotificationRead,
  listAuditLogs,
  getPredictions,
  listSuppliers,
  createSupplier,
} from '../controllers/miscController.js';
import { authenticate } from '../middleware/auth.js';
import { requireOrg, enforceOrgIsolation, minRole, viewerReadOnly } from '../middleware/rbac.js';
import { ROLES } from '../config/constants.js';

const router = Router();

router.use(authenticate, requireOrg, enforceOrgIsolation, viewerReadOnly);

router.get('/analytics', getAnalytics);
router.get('/reports', minRole(ROLES.ORG_ADMIN), generateReport);
router.get('/predictions', minRole(ROLES.ORG_ADMIN), getPredictions);
router.get('/predictions/:itemId', minRole(ROLES.ORG_ADMIN), getPredictions);

router.get('/users', minRole(ROLES.ORG_ADMIN), listUsers);
router.put('/users/:id', minRole(ROLES.ORG_ADMIN), updateUser);

router.get('/departments', crudDepartment.list);
router.post('/departments', minRole(ROLES.ORG_ADMIN), crudDepartment.create);
router.put('/departments/:id', minRole(ROLES.ORG_ADMIN), crudDepartment.update);

router.get('/categories', crudCategory.list);
router.post('/categories', minRole(ROLES.ORG_ADMIN), crudCategory.create);

router.get('/locations', crudLocation.list);
router.post('/locations', minRole(ROLES.ORG_ADMIN), crudLocation.create);

router.get('/template', getTemplate);
router.put('/template', minRole(ROLES.ORG_ADMIN), updateTemplate);

router.get('/notifications', listNotifications);
router.put('/notifications/:id/read', markNotificationRead);

router.get('/audit-logs', minRole(ROLES.ORG_ADMIN), listAuditLogs);

router.get('/suppliers', listSuppliers);
router.post('/suppliers', minRole(ROLES.ORG_ADMIN), createSupplier);

export default router;
