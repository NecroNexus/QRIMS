import { Router } from 'express';
import {
  listMaintenance,
  createMaintenance,
  updateMaintenance,
  getItemMaintenance,
} from '../controllers/maintenanceController.js';
import { authenticate } from '../middleware/auth.js';
import { requireOrg, enforceOrgIsolation, minRole, viewerReadOnly } from '../middleware/rbac.js';
import { ROLES } from '../config/constants.js';

const router = Router();

router.use(authenticate, requireOrg, enforceOrgIsolation, viewerReadOnly);

router.get('/', listMaintenance);
router.post('/', minRole(ROLES.STAFF), createMaintenance);
router.put('/:id', minRole(ROLES.DEPT_MANAGER), updateMaintenance);
router.get('/item/:itemId', getItemMaintenance);

export default router;
