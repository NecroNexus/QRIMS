import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import {
  listItems,
  getItem,
  createItem,
  updateItem,
  deleteItem,
  scanQr,
  stockIn,
  stockOut,
  getTransactions,
  assignItem,
  transferItem,
  getQrCode,
  globalSearch,
  getExpiringItems,
} from '../controllers/inventoryController.js';
import { authenticate } from '../middleware/auth.js';
import { requireOrg, enforceOrgIsolation, minRole, viewerReadOnly, deptManagerScope } from '../middleware/rbac.js';
import { validate } from '../middleware/validate.js';
import { inventoryValidation, stockValidation } from '../validators/authValidators.js';
import { ROLES } from '../config/constants.js';
import { uploadImage } from '../services/uploadService.js';
import { apiResponse, apiError } from '../utils/helpers.js';

const uploadDir = 'uploads';
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: uploadDir,
  filename: (_req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`),
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = /jpeg|jpg|png|webp|gif/;
    const ext = allowed.test(path.extname(file.originalname).toLowerCase());
    const mime = allowed.test(file.mimetype);
    cb(ext && mime ? null : new Error('Invalid image type'), ext && mime);
  },
});

const router = Router();

router.use(authenticate, requireOrg, enforceOrgIsolation, viewerReadOnly, deptManagerScope);

router.get('/search', globalSearch);
router.get('/expiring', getExpiringItems);
router.get('/', listItems);
router.get('/scan/:qrId', scanQr);
router.post('/scan', scanQr);
router.get('/:id', getItem);
router.get('/:id/qr', getQrCode);
router.get('/:id/transactions', getTransactions);

router.post('/', minRole(ROLES.STAFF), inventoryValidation, validate, createItem);
router.put('/:id', minRole(ROLES.STAFF), updateItem);
router.delete('/:id', minRole(ROLES.ORG_ADMIN), deleteItem);
router.post('/:id/stock-in', minRole(ROLES.STAFF), stockValidation, validate, stockIn);
router.post('/:id/stock-out', minRole(ROLES.STAFF), stockValidation, validate, stockOut);
router.post('/:id/assign', minRole(ROLES.STAFF), assignItem);
router.post('/:id/transfer', minRole(ROLES.STAFF), transferItem);

router.post('/:id/image', minRole(ROLES.STAFF), upload.single('image'), async (req, res, next) => {
  try {
    if (!req.file) return apiError(res, 400, 'No image uploaded');
    const result = await uploadImage(req.file.path);
    req.body = { imageUrl: result.url, imagePublicId: result.publicId };
    req.params.id = req.params.id;
    return updateItem(req, res, next);
  } catch (err) {
    next(err);
  }
});

export default router;
