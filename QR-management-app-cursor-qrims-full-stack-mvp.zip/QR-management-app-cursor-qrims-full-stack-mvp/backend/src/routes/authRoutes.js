import { Router } from 'express';
import { register, login, getMe, forgotPassword, resetPassword, onboarding } from '../controllers/authController.js';
import { authenticate } from '../middleware/auth.js';
import { authLimiter } from '../middleware/rateLimiter.js';
import { validate } from '../middleware/validate.js';
import { loginValidation, registerValidation, onboardingValidation } from '../validators/authValidators.js';
import { authorize, minRole } from '../middleware/rbac.js';
import { ROLES } from '../config/constants.js';

const router = Router();

router.post('/onboarding', onboardingValidation, validate, onboarding);
router.post('/login', authLimiter, loginValidation, validate, login);
router.post('/register', authenticate, registerValidation, validate, register);
router.post('/forgot-password', authLimiter, forgotPassword);
router.post('/reset-password', authLimiter, resetPassword);
router.get('/me', authenticate, getMe);
router.post('/logout', authenticate, (_req, res) => {
  res.json({ success: true, message: 'Logged out' });
});

export default router;
