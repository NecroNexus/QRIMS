import { Router } from 'express';
import {
  listOrganizations,
  getOrganization,
  updateOrganization,
  changeOrgType,
  getOrgStats,
} from '../controllers/organizationController.js';
import { authenticate } from '../middleware/auth.js';
import { authorize, requireOrg, enforceOrgIsolation, minRole } from '../middleware/rbac.js';
import { ROLES } from '../config/constants.js';

const router = Router();

router.use(authenticate);

router.get('/', authorize(ROLES.SUPER_ADMIN), listOrganizations);
router.get('/me', requireOrg, enforceOrgIsolation, getOrganization);
router.get('/me/stats', requireOrg, enforceOrgIsolation, getOrgStats);
router.put('/me', requireOrg, enforceOrgIsolation, minRole(ROLES.ORG_ADMIN), updateOrganization);
router.put('/me/type', requireOrg, enforceOrgIsolation, minRole(ROLES.ORG_ADMIN), changeOrgType);
router.get('/:id', authorize(ROLES.SUPER_ADMIN), getOrganization);

export default router;
