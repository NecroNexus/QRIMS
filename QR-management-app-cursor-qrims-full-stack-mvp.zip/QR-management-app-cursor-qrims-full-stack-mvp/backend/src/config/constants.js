export const ROLES = {
  SUPER_ADMIN: 'super_admin',
  ORG_ADMIN: 'org_admin',
  DEPT_MANAGER: 'dept_manager',
  STAFF: 'staff',
  VIEWER: 'viewer',
};

export const ORG_TYPES = [
  'college',
  'hospital',
  'library',
  'office',
  'retail',
  'warehouse',
  'manufacturing',
  'restaurant',
  'custom',
];

export const ITEM_STATUSES = [
  'available',
  'assigned',
  'in_use',
  'low_stock',
  'out_of_stock',
  'maintenance',
  'damaged',
  'lost',
  'disposed',
];

export const FIELD_TYPES = [
  'text',
  'number',
  'date',
  'boolean',
  'dropdown',
  'currency',
  'email',
  'image',
];

export const MAINTENANCE_STATUSES = [
  'requested',
  'approved',
  'in_progress',
  'completed',
  'rejected',
];

export const MAINTENANCE_PRIORITIES = ['low', 'medium', 'high', 'critical'];

export const LIFECYCLE_EVENTS = [
  'purchased',
  'stored',
  'assigned',
  'in_use',
  'maintenance',
  'repaired',
  'returned',
  'disposed',
  'transferred',
];

export const NOTIFICATION_TYPES = [
  'low_stock',
  'out_of_stock',
  'expiring',
  'maintenance_due',
  'maintenance_overdue',
  'assignment',
  'stock_request',
  'approval_request',
  'general',
];

export const ROLE_HIERARCHY = {
  super_admin: 5,
  org_admin: 4,
  dept_manager: 3,
  staff: 2,
  viewer: 1,
};

export const ORG_TYPE_TEMPLATES = {
  college: {
    categories: ['Electronics', 'Lab Equipment', 'Furniture', 'Networking'],
    fields: [
      { key: 'assetId', label: 'Asset ID', type: 'text', required: true },
      { key: 'department', label: 'Department', type: 'text', required: true },
      { key: 'lab', label: 'Lab', type: 'text', required: false },
      { key: 'condition', label: 'Condition', type: 'dropdown', required: true, options: ['New', 'Good', 'Fair', 'Poor'] },
      { key: 'warrantyExpiry', label: 'Warranty Expiry', type: 'date', required: false },
      { key: 'assignedTo', label: 'Assigned To', type: 'text', required: false },
    ],
  },
  hospital: {
    categories: ['Medical Equipment', 'Supplies', 'Mobility', 'Monitoring'],
    fields: [
      { key: 'equipmentId', label: 'Equipment ID', type: 'text', required: true },
      { key: 'manufacturer', label: 'Manufacturer', type: 'text', required: false },
      { key: 'serialNumber', label: 'Serial Number', type: 'text', required: true },
      { key: 'maintenanceDate', label: 'Last Maintenance', type: 'date', required: false },
      { key: 'equipmentStatus', label: 'Equipment Status', type: 'dropdown', required: true, options: ['Operational', 'Calibration Due', 'Under Repair'] },
    ],
  },
  library: {
    categories: ['Books', 'Computers', 'AV Equipment', 'Reference'],
    fields: [
      { key: 'bookId', label: 'Book ID', type: 'text', required: true },
      { key: 'author', label: 'Author', type: 'text', required: true },
      { key: 'isbn', label: 'ISBN', type: 'text', required: false },
      { key: 'rackNumber', label: 'Rack Number', type: 'text', required: true },
      { key: 'availability', label: 'Availability', type: 'dropdown', required: true, options: ['Available', 'Borrowed', 'Reserved'] },
      { key: 'borrower', label: 'Borrower', type: 'text', required: false },
    ],
  },
  office: {
    categories: ['Furniture', 'Electronics', 'Supplies', 'IT'],
    fields: [
      { key: 'assetTag', label: 'Asset Tag', type: 'text', required: true },
      { key: 'assignedDesk', label: 'Assigned Desk', type: 'text', required: false },
    ],
  },
  retail: {
    categories: ['Products', 'Packaging', 'Display', 'Consumables'],
    fields: [
      { key: 'productId', label: 'Product ID', type: 'text', required: true },
      { key: 'price', label: 'Price', type: 'currency', required: true },
      { key: 'expiryDate', label: 'Expiry Date', type: 'date', required: false },
      { key: 'barcode', label: 'Barcode', type: 'text', required: false },
    ],
  },
  warehouse: {
    categories: ['Electronics', 'Components', 'Packaging', 'Raw Materials'],
    fields: [
      { key: 'sku', label: 'SKU', type: 'text', required: true },
      { key: 'binLocation', label: 'Bin Location', type: 'text', required: true },
      { key: 'palletId', label: 'Pallet ID', type: 'text', required: false },
    ],
  },
  manufacturing: {
    categories: ['Raw Materials', 'Work in Progress', 'Finished Goods', 'Tools'],
    fields: [
      { key: 'partNumber', label: 'Part Number', type: 'text', required: true },
      { key: 'batchNumber', label: 'Batch Number', type: 'text', required: false },
      { key: 'productionLine', label: 'Production Line', type: 'text', required: false },
    ],
  },
  restaurant: {
    categories: ['Food', 'Beverages', 'Kitchen Equipment', 'Tableware'],
    fields: [
      { key: 'batchCode', label: 'Batch Code', type: 'text', required: false },
      { key: 'expiryDate', label: 'Expiry Date', type: 'date', required: true },
      { key: 'storageTemp', label: 'Storage Temperature', type: 'text', required: false },
    ],
  },
  custom: {
    categories: ['General'],
    fields: [
      { key: 'customId', label: 'Custom ID', type: 'text', required: false },
    ],
  },
};
