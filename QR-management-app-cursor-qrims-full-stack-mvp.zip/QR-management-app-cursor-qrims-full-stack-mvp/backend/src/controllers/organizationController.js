import Organization from '../models/Organization.js';
import User from '../models/User.js';
import InventoryItem from '../models/InventoryItem.js';
import { apiResponse, apiError } from '../utils/helpers.js';
import { createDefaultTemplate } from '../services/templateService.js';
import { createAuditLog } from '../services/auditService.js';
import { ORG_TYPES } from '../config/constants.js';

export const listOrganizations = async (req, res, next) => {
  try {
    const orgs = await Organization.find().sort('-createdAt');
    apiResponse(res, 200, { organizations: orgs });
  } catch (err) {
    next(err);
  }
};

export const getOrganization = async (req, res, next) => {
  try {
    const orgId = req.params.id || req.organizationId;
    const org = await Organization.findById(orgId);
    if (!org) return apiError(res, 404, 'Organization not found');
    apiResponse(res, 200, { organization: org });
  } catch (err) {
    next(err);
  }
};

export const updateOrganization = async (req, res, next) => {
  try {
    const orgId = req.params.id || req.organizationId;
    const org = await Organization.findByIdAndUpdate(orgId, req.body, { new: true, runValidators: true });
    if (!org) return apiError(res, 404, 'Organization not found');

    await createAuditLog({
      organization: org._id,
      user: req.user._id,
      action: 'organization_updated',
      entityType: 'Organization',
      entityId: org._id,
      metadata: req.body,
    });

    apiResponse(res, 200, { organization: org });
  } catch (err) {
    next(err);
  }
};

export const changeOrgType = async (req, res, next) => {
  try {
    const { type } = req.body;
    if (!ORG_TYPES.includes(type)) return apiError(res, 400, 'Invalid organization type');

    const orgId = req.params.id || req.organizationId;
    const org = await Organization.findByIdAndUpdate(orgId, { type }, { new: true });
    if (!org) return apiError(res, 404, 'Organization not found');

    await createDefaultTemplate(org._id, type);

    await createAuditLog({
      organization: org._id,
      user: req.user._id,
      action: 'organization_type_changed',
      entityType: 'Organization',
      entityId: org._id,
      metadata: { newType: type },
    });

    apiResponse(res, 200, { organization: org }, 'Organization type updated with new template');
  } catch (err) {
    next(err);
  }
};

export const getOrgStats = async (req, res, next) => {
  try {
    const orgId = req.params.id || req.organizationId;
    const [itemCount, userCount, totalValue] = await Promise.all([
      InventoryItem.countDocuments({ organization: orgId, isDeleted: false }),
      User.countDocuments({ organization: orgId, isActive: true }),
      InventoryItem.aggregate([
        { $match: { organization: orgId, isDeleted: false } },
        { $group: { _id: null, total: { $sum: { $multiply: ['$quantity', '$cost'] } } } },
      ]),
    ]);

    apiResponse(res, 200, {
      stats: {
        itemCount,
        userCount,
        totalValue: totalValue[0]?.total || 0,
      },
    });
  } catch (err) {
    next(err);
  }
};
