import MaintenanceRequest from '../models/MaintenanceRequest.js';
import InventoryItem from '../models/InventoryItem.js';
import { createAuditLog } from '../services/auditService.js';
import { createNotification, notifyOrgAdmins } from '../services/notificationService.js';
import { apiResponse, apiError, paginate } from '../utils/helpers.js';
import { ROLES } from '../config/constants.js';

const orgFilter = (req) => ({ organization: req.organizationId });

export const listMaintenance = async (req, res, next) => {
  try {
    const { status, priority, page, limit } = req.query;
    const filter = orgFilter(req);
    if (status) filter.status = status;
    if (priority) filter.priority = priority;

    const query = MaintenanceRequest.find(filter)
      .populate('item', 'name qrId status')
      .populate('submittedBy approvedBy', 'name email');

    const [requests, total] = await Promise.all([
      paginate(query, { page, limit }),
      MaintenanceRequest.countDocuments(filter),
    ]);

    apiResponse(res, 200, { requests, pagination: { total } });
  } catch (err) {
    next(err);
  }
};

export const createMaintenance = async (req, res, next) => {
  try {
    const item = await InventoryItem.findOne({ _id: req.body.item, organization: req.organizationId, isDeleted: false });
    if (!item) return apiError(res, 404, 'Item not found');

    const request = await MaintenanceRequest.create({
      ...req.body,
      organization: req.organizationId,
      submittedBy: req.user._id,
    });

    item.status = 'maintenance';
    item.lifecycleHistory.push({ event: 'maintenance', performedBy: req.user._id, note: req.body.problem });
    await item.save();

    await notifyOrgAdmins(req.organizationId, {
      type: 'approval_request',
      title: 'Maintenance Request',
      message: `New maintenance request for ${item.name}: ${req.body.problem}`,
      relatedItem: item._id,
      relatedEntity: request._id,
    });

    await createAuditLog({
      organization: req.organizationId,
      user: req.user._id,
      action: 'maintenance_created',
      item: item._id,
      entityId: request._id,
    });

    apiResponse(res, 201, { request });
  } catch (err) {
    next(err);
  }
};

export const updateMaintenance = async (req, res, next) => {
  try {
    const request = await MaintenanceRequest.findOne({ _id: req.params.id, ...orgFilter(req) });
    if (!request) return apiError(res, 404, 'Maintenance request not found');

    const prevStatus = request.status;
    Object.assign(request, req.body);

    if (req.body.status === 'approved' && [ROLES.ORG_ADMIN, ROLES.DEPT_MANAGER].includes(req.user.role)) {
      request.approvedBy = req.user._id;
    }

    if (req.body.status === 'completed') {
      request.completedAt = new Date();
      const item = await InventoryItem.findById(request.item);
      if (item) {
        item.status = 'available';
        item.lifecycleHistory.push({ event: 'repaired', performedBy: req.user._id });
        await item.save();
      }
    }

    await request.save();

    await createAuditLog({
      organization: req.organizationId,
      user: req.user._id,
      action: 'maintenance_updated',
      entityId: request._id,
      metadata: { from: prevStatus, to: request.status },
    });

    apiResponse(res, 200, { request });
  } catch (err) {
    next(err);
  }
};

export const getItemMaintenance = async (req, res, next) => {
  try {
    const history = await MaintenanceRequest.find({ item: req.params.itemId, ...orgFilter(req) })
      .sort('-createdAt')
      .populate('submittedBy', 'name');
    apiResponse(res, 200, { history });
  } catch (err) {
    next(err);
  }
};
