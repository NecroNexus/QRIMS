import InventoryItem from '../models/InventoryItem.js';
import InventoryTemplate from '../models/InventoryTemplate.js';
import StockTransaction from '../models/StockTransaction.js';
import Assignment from '../models/Assignment.js';
import MaintenanceRequest from '../models/MaintenanceRequest.js';
import Category from '../models/Category.js';
import { generateQrId } from '../utils/helpers.js';
import { generateQrCodeDataUrl, parseQrPayload } from '../services/qrService.js';
import { validateCustomFields } from '../services/templateService.js';
import { createAuditLog } from '../services/auditService.js';
import { checkStockNotifications, checkExpiryNotifications } from '../services/notificationService.js';
import { createNotification } from '../services/notificationService.js';
import { apiResponse, apiError, paginate, buildSearchRegex } from '../utils/helpers.js';
import { ROLES } from '../config/constants.js';

const orgFilter = (req) => {
  const filter = { organization: req.organizationId, isDeleted: false };
  if (req.user.role === ROLES.DEPT_MANAGER && req.user.department) {
    filter.department = req.user.department;
  }
  return filter;
};

export const listItems = async (req, res, next) => {
  try {
    const { page, limit, sort, status, category, department, location, search } = req.query;
    const filter = orgFilter(req);
    if (status) filter.status = status;
    if (category) filter.category = category;
    if (department) filter.department = department;
    if (location) filter.location = location;
    if (search) {
      filter.$or = [
        { name: buildSearchRegex(search) },
        { qrId: buildSearchRegex(search) },
        { description: buildSearchRegex(search) },
      ];
    }

    const query = InventoryItem.find(filter)
      .populate('category', 'name color')
      .populate('department', 'name')
      .populate('location', 'name')
      .populate('assignedTo', 'name email')
      .populate('supplier', 'name');

    const [items, total] = await Promise.all([
      paginate(query, { page, limit, sort }),
      InventoryItem.countDocuments(filter),
    ]);

    apiResponse(res, 200, { items, pagination: { page: Number(page) || 1, limit: Number(limit) || 20, total } });
  } catch (err) {
    next(err);
  }
};

export const getItem = async (req, res, next) => {
  try {
    const item = await InventoryItem.findOne({ _id: req.params.id, ...orgFilter(req) })
      .populate('category department location assignedTo supplier createdBy', 'name email');

    if (!item) return apiError(res, 404, 'Item not found');
    apiResponse(res, 200, { item });
  } catch (err) {
    next(err);
  }
};

export const createItem = async (req, res, next) => {
  try {
    const org = await import('../models/Organization.js').then((m) => m.default.findById(req.organizationId));
    const template = await InventoryTemplate.findOne({ organization: req.organizationId, isDefault: true });
    const { errors, normalized } = validateCustomFields(template?.fields || [], req.body.customFields || {});

    if (errors.length) return apiError(res, 400, errors.join(', '));

    const qrId = generateQrId(org.orgCode);
    const item = await InventoryItem.create({
      ...req.body,
      qrId,
      organization: req.organizationId,
      customFields: normalized,
      createdBy: req.user._id,
    });

    item.updateStatusFromQuantity();
    await item.save();

    item.lifecycleHistory.push({
      event: 'purchased',
      toStatus: item.status,
      performedBy: req.user._id,
      note: 'Item created',
    });
    await item.save();

    const qrCodeDataUrl = await generateQrCodeDataUrl(qrId);

    await createAuditLog({
      organization: req.organizationId,
      user: req.user._id,
      action: 'item_created',
      entityType: 'InventoryItem',
      entityId: item._id,
      item: item._id,
    });

    apiResponse(res, 201, { item, qrCodeDataUrl }, 'Item created');
  } catch (err) {
    next(err);
  }
};

export const updateItem = async (req, res, next) => {
  try {
    const item = await InventoryItem.findOne({ _id: req.params.id, ...orgFilter(req) });
    if (!item) return apiError(res, 404, 'Item not found');

    const template = await InventoryTemplate.findOne({ organization: req.organizationId, isDefault: true });
    if (req.body.customFields) {
      const { errors, normalized } = validateCustomFields(template?.fields || [], req.body.customFields);
      if (errors.length) return apiError(res, 400, errors.join(', '));
      req.body.customFields = normalized;
    }

    const prevStatus = item.status;
    Object.assign(item, req.body);
    item.updateStatusFromQuantity();
    await item.save();

    if (prevStatus !== item.status) {
      item.lifecycleHistory.push({
        event: 'status_change',
        fromStatus: prevStatus,
        toStatus: item.status,
        performedBy: req.user._id,
      });
      await item.save();
    }

    await createAuditLog({
      organization: req.organizationId,
      user: req.user._id,
      action: 'item_updated',
      entityType: 'InventoryItem',
      entityId: item._id,
      item: item._id,
    });

    apiResponse(res, 200, { item });
  } catch (err) {
    next(err);
  }
};

export const deleteItem = async (req, res, next) => {
  try {
    const item = await InventoryItem.findOne({ _id: req.params.id, ...orgFilter(req) });
    if (!item) return apiError(res, 404, 'Item not found');

    item.isDeleted = true;
    item.status = 'disposed';
    await item.save();

    await createAuditLog({
      organization: req.organizationId,
      user: req.user._id,
      action: 'item_deleted',
      item: item._id,
    });

    apiResponse(res, 200, null, 'Item deleted');
  } catch (err) {
    next(err);
  }
};

export const scanQr = async (req, res, next) => {
  try {
    const qrId = parseQrPayload(req.params.qrId || req.body.qrId);
    const item = await InventoryItem.findOne({ qrId, organization: req.organizationId, isDeleted: false })
      .populate('category department location assignedTo supplier');

    if (!item) return apiError(res, 404, 'Item not found for this organization');

    const [transactions, maintenance, assignments] = await Promise.all([
      StockTransaction.find({ item: item._id }).sort('-createdAt').limit(10).populate('performedBy', 'name'),
      MaintenanceRequest.find({ item: item._id }).sort('-createdAt').limit(5),
      Assignment.find({ item: item._id, status: 'active' }).populate('assignedTo', 'name email'),
    ]);

    apiResponse(res, 200, { item, transactions, maintenance, assignments });
  } catch (err) {
    next(err);
  }
};

export const stockIn = async (req, res, next) => {
  try {
    const { quantity, supplier, referenceNumber, notes } = req.body;
    const item = await InventoryItem.findOne({ _id: req.params.id, ...orgFilter(req) });
    if (!item) return apiError(res, 404, 'Item not found');

    const prev = item.quantity;
    item.quantity += Number(quantity);
    item.updateStatusFromQuantity();
    await item.save();

    const tx = await StockTransaction.create({
      organization: req.organizationId,
      item: item._id,
      type: 'stock_in',
      quantity: Number(quantity),
      previousQuantity: prev,
      newQuantity: item.quantity,
      performedBy: req.user._id,
      supplier,
      referenceNumber,
      notes,
    });

    await createAuditLog({
      organization: req.organizationId,
      user: req.user._id,
      action: 'stock_in',
      item: item._id,
      metadata: { quantity, referenceNumber },
    });

    apiResponse(res, 200, { item, transaction: tx });
  } catch (err) {
    next(err);
  }
};

export const stockOut = async (req, res, next) => {
  try {
    const { quantity, destination, reason, notes } = req.body;
    const item = await InventoryItem.findOne({ _id: req.params.id, ...orgFilter(req) });
    if (!item) return apiError(res, 404, 'Item not found');

    const qty = Number(quantity);
    if (item.quantity - qty < 0) {
      return apiError(res, 400, 'Insufficient stock. Cannot go negative.');
    }

    const prev = item.quantity;
    item.quantity -= qty;
    item.updateStatusFromQuantity();
    await item.save();

    const tx = await StockTransaction.create({
      organization: req.organizationId,
      item: item._id,
      type: 'stock_out',
      quantity: qty,
      previousQuantity: prev,
      newQuantity: item.quantity,
      performedBy: req.user._id,
      destination,
      reason,
      notes,
    });

    await checkStockNotifications(item, req.user._id);

    await createAuditLog({
      organization: req.organizationId,
      user: req.user._id,
      action: 'stock_out',
      item: item._id,
      metadata: { quantity: qty, reason },
    });

    apiResponse(res, 200, { item, transaction: tx });
  } catch (err) {
    next(err);
  }
};

export const getTransactions = async (req, res, next) => {
  try {
    const item = await InventoryItem.findOne({ _id: req.params.id, ...orgFilter(req) });
    if (!item) return apiError(res, 404, 'Item not found');

    const transactions = await StockTransaction.find({ item: item._id })
      .sort('-createdAt')
      .populate('performedBy', 'name email');

    apiResponse(res, 200, { transactions });
  } catch (err) {
    next(err);
  }
};

export const assignItem = async (req, res, next) => {
  try {
    const { assignedTo, department, notes } = req.body;
    const item = await InventoryItem.findOne({ _id: req.params.id, ...orgFilter(req) });
    if (!item) return apiError(res, 404, 'Item not found');

    const prevStatus = item.status;
    item.assignedTo = assignedTo;
    item.department = department || item.department;
    item.status = 'assigned';
    item.lifecycleHistory.push({
      event: 'assigned',
      fromStatus: prevStatus,
      toStatus: 'assigned',
      performedBy: req.user._id,
      note: notes,
    });
    await item.save();

    const assignment = await Assignment.create({
      organization: req.organizationId,
      item: item._id,
      assignedTo,
      assignedBy: req.user._id,
      department: item.department,
      notes,
    });

    await createNotification({
      organization: req.organizationId,
      userId: assignedTo,
      type: 'assignment',
      title: 'New Assignment',
      message: `You have been assigned: ${item.name}`,
      relatedItem: item._id,
    });

    await createAuditLog({
      organization: req.organizationId,
      user: req.user._id,
      action: 'item_assigned',
      item: item._id,
      metadata: { assignedTo },
    });

    apiResponse(res, 200, { item, assignment });
  } catch (err) {
    next(err);
  }
};

export const transferItem = async (req, res, next) => {
  try {
    const { department, location, reason } = req.body;
    const item = await InventoryItem.findOne({ _id: req.params.id, ...orgFilter(req) });
    if (!item) return apiError(res, 404, 'Item not found');

    const prevLocation = item.location;
    const prevDepartment = item.department;

    if (department) item.department = department;
    if (location) item.location = location;

    item.lifecycleHistory.push({
      event: 'transferred',
      performedBy: req.user._id,
      note: reason,
      metadata: { fromDepartment: prevDepartment, toDepartment: department, fromLocation: prevLocation, toLocation: location },
    });
    await item.save();

    await createAuditLog({
      organization: req.organizationId,
      user: req.user._id,
      action: 'item_transferred',
      item: item._id,
      metadata: { department, location, reason },
    });

    apiResponse(res, 200, { item });
  } catch (err) {
    next(err);
  }
};

export const getQrCode = async (req, res, next) => {
  try {
    const item = await InventoryItem.findOne({ _id: req.params.id, ...orgFilter(req) });
    if (!item) return apiError(res, 404, 'Item not found');
    const qrCodeDataUrl = await generateQrCodeDataUrl(item.qrId);
    apiResponse(res, 200, { qrId: item.qrId, qrCodeDataUrl });
  } catch (err) {
    next(err);
  }
};

export const globalSearch = async (req, res, next) => {
  try {
    const { q, status, category, department, sort } = req.query;
    const filter = orgFilter(req);
    if (status) filter.status = status;
    if (category) filter.category = category;
    if (department) filter.department = department;

    if (q) {
      filter.$or = [
        { name: buildSearchRegex(q) },
        { qrId: buildSearchRegex(q) },
        { description: buildSearchRegex(q) },
      ];
    }

    const items = await InventoryItem.find(filter)
      .populate('category', 'name')
      .populate('department', 'name')
      .sort(sort || '-updatedAt')
      .limit(50);

    apiResponse(res, 200, { items, count: items.length });
  } catch (err) {
    next(err);
  }
};

export const getExpiringItems = async (req, res, next) => {
  try {
    const days = Number(req.query.days) || 30;
    const threshold = new Date();
    threshold.setDate(threshold.getDate() + days);

    const items = await InventoryItem.find({
      ...orgFilter(req),
      expiryDate: { $lte: threshold, $gte: new Date() },
    }).sort('expiryDate');

    apiResponse(res, 200, { items });
  } catch (err) {
    next(err);
  }
};
