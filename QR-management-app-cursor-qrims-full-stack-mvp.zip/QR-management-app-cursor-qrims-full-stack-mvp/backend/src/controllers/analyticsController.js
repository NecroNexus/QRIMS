import InventoryItem from '../models/InventoryItem.js';
import StockTransaction from '../models/StockTransaction.js';
import MaintenanceRequest from '../models/MaintenanceRequest.js';
import Category from '../models/Category.js';
import Department from '../models/Department.js';
import { apiResponse } from '../utils/helpers.js';

export const getAnalytics = async (req, res, next) => {
  try {
    const orgId = req.organizationId;
    const baseFilter = { organization: orgId, isDeleted: false };

    const [
      totalItems,
      statusBreakdown,
      categoryBreakdown,
      deptBreakdown,
      totalValue,
      lowStock,
      outOfStock,
      underMaintenance,
      expiringSoon,
      recentTransactions,
      topUsed,
    ] = await Promise.all([
      InventoryItem.countDocuments(baseFilter),
      InventoryItem.aggregate([
        { $match: baseFilter },
        { $group: { _id: '$status', count: { $sum: 1 } } },
      ]),
      InventoryItem.aggregate([
        { $match: baseFilter },
        { $group: { _id: '$category', count: { $sum: 1 }, value: { $sum: { $multiply: ['$quantity', '$cost'] } } } },
        { $lookup: { from: 'categories', localField: '_id', foreignField: '_id', as: 'cat' } },
        { $project: { name: { $arrayElemAt: ['$cat.name', 0] }, count: 1, value: 1 } },
      ]),
      InventoryItem.aggregate([
        { $match: baseFilter },
        { $group: { _id: '$department', count: { $sum: 1 }, value: { $sum: { $multiply: ['$quantity', '$cost'] } } } },
        { $lookup: { from: 'departments', localField: '_id', foreignField: '_id', as: 'dept' } },
        { $project: { name: { $arrayElemAt: ['$dept.name', 0] }, count: 1, value: 1 } },
      ]),
      InventoryItem.aggregate([
        { $match: baseFilter },
        { $group: { _id: null, total: { $sum: { $multiply: ['$quantity', '$cost'] } } } },
      ]),
      InventoryItem.countDocuments({ ...baseFilter, status: 'low_stock' }),
      InventoryItem.countDocuments({ ...baseFilter, status: 'out_of_stock' }),
      InventoryItem.countDocuments({ ...baseFilter, status: 'maintenance' }),
      InventoryItem.countDocuments({
        ...baseFilter,
        expiryDate: { $lte: new Date(Date.now() + 30 * 86400000), $gte: new Date() },
      }),
      StockTransaction.find({ organization: orgId })
        .sort('-createdAt')
        .limit(10)
        .populate('item', 'name qrId')
        .populate('performedBy', 'name'),
      StockTransaction.aggregate([
        { $match: { organization: orgId, type: 'stock_out' } },
        { $group: { _id: '$item', totalUsed: { $sum: '$quantity' } } },
        { $sort: { totalUsed: -1 } },
        { $limit: 5 },
        { $lookup: { from: 'inventoryitems', localField: '_id', foreignField: '_id', as: 'item' } },
        { $project: { name: { $arrayElemAt: ['$item.name', 0] }, totalUsed: 1 } },
      ]),
    ]);

    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const monthlyMovement = await StockTransaction.aggregate([
      { $match: { organization: orgId, createdAt: { $gte: sixMonthsAgo } } },
      {
        $group: {
          _id: { month: { $month: '$createdAt' }, year: { $year: '$createdAt' }, type: '$type' },
          total: { $sum: '$quantity' },
        },
      },
      { $sort: { '_id.year': 1, '_id.month': 1 } },
    ]);

    const maintenanceStats = await MaintenanceRequest.aggregate([
      { $match: { organization: orgId } },
      { $group: { _id: '$status', count: { $sum: 1 } } },
    ]);

    apiResponse(res, 200, {
      analytics: {
        totalItems,
        totalValue: totalValue[0]?.total || 0,
        availableItems: statusBreakdown.find((s) => s._id === 'available')?.count || 0,
        lowStock,
        outOfStock,
        underMaintenance,
        expiringSoon,
        statusBreakdown,
        categoryBreakdown,
        departmentBreakdown: deptBreakdown,
        recentTransactions,
        mostUsedItems: topUsed,
        monthlyMovement,
        maintenanceStats,
      },
    });
  } catch (err) {
    next(err);
  }
};
