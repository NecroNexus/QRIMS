import User from '../models/User.js';
import Organization from '../models/Organization.js';
import Department from '../models/Department.js';
import InventoryTemplate from '../models/InventoryTemplate.js';
import { signAccessToken } from '../utils/jwt.js';
import { generateOrgCode, generateResetToken, hashToken, apiResponse, apiError } from '../utils/helpers.js';
import { createDefaultTemplate } from '../services/templateService.js';
import { createAuditLog } from '../services/auditService.js';
import { ROLES } from '../config/constants.js';

export const register = async (req, res, next) => {
  try {
    const { name, email, password, role, organizationId } = req.body;

    if (role === ROLES.SUPER_ADMIN && req.user?.role !== ROLES.SUPER_ADMIN) {
      return apiError(res, 403, 'Only super admin can create super admin accounts');
    }

    const existing = await User.findOne({ email });
    if (existing) return apiError(res, 409, 'Email already registered');

    const user = await User.create({
      name,
      email,
      password,
      role: role || ROLES.STAFF,
      organization: organizationId || req.user?.organization,
    });

    await createAuditLog({
      organization: user.organization,
      user: user._id,
      action: 'user_created',
      entityType: 'User',
      entityId: user._id,
      ipAddress: req.ip,
    });

    const token = signAccessToken({ id: user._id, role: user.role, org: user.organization });
    apiResponse(res, 201, { user: sanitizeUser(user), token }, 'Registration successful');
  } catch (err) {
    next(err);
  }
};

export const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email }).select('+password').populate('organization', 'name orgCode type');
    if (!user || !(await user.comparePassword(password))) {
      return apiError(res, 401, 'Invalid email or password');
    }
    if (!user.isActive) return apiError(res, 403, 'Account is deactivated');

    user.lastLogin = new Date();
    await user.save();

    await createAuditLog({
      organization: user.organization,
      user: user._id,
      action: 'login',
      ipAddress: req.ip,
    });

    const token = signAccessToken({ id: user._id, role: user.role, org: user.organization?._id });
    apiResponse(res, 200, { user: sanitizeUser(user), token }, 'Login successful');
  } catch (err) {
    next(err);
  }
};

export const getMe = async (req, res) => {
  const user = await User.findById(req.user._id)
    .populate('organization', 'name orgCode type settings')
    .populate('department', 'name');
  apiResponse(res, 200, { user: sanitizeUser(user) });
};

export const forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });
    if (!user) {
      return apiResponse(res, 200, { resetToken: null }, 'If account exists, reset instructions sent');
    }

    const resetToken = generateResetToken();
    user.resetPasswordToken = hashToken(resetToken);
    user.resetPasswordExpires = new Date(Date.now() + (Number(process.env.RESET_TOKEN_EXPIRY_HOURS) || 24) * 3600000);
    await user.save();

    apiResponse(res, 200, {
      resetToken,
      message: 'Use this token with reset-password endpoint (demo mode - no email sent)',
    });
  } catch (err) {
    next(err);
  }
};

export const resetPassword = async (req, res, next) => {
  try {
    const { token, password } = req.body;
    const user = await User.findOne({
      resetPasswordToken: hashToken(token),
      resetPasswordExpires: { $gt: new Date() },
    }).select('+resetPasswordToken +resetPasswordExpires +password');

    if (!user) return apiError(res, 400, 'Invalid or expired reset token');

    user.password = password;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;
    await user.save();

    apiResponse(res, 200, null, 'Password reset successful');
  } catch (err) {
    next(err);
  }
};

export const onboarding = async (req, res, next) => {
  try {
    const { organizationName, organizationType, departments, adminName, adminEmail, adminPassword, settings } = req.body;

    const orgCode = generateOrgCode();
    const organization = await Organization.create({
      name: organizationName,
      orgCode,
      type: organizationType,
      onboardingComplete: true,
      settings: settings || {},
    });

    const template = await createDefaultTemplate(organization._id, organizationType);

    const createdDepts = [];
    if (departments?.length) {
      for (const dept of departments) {
        const d = await Department.create({
          name: dept.name || dept,
          code: dept.code,
          organization: organization._id,
          description: dept.description,
        });
        createdDepts.push(d);
      }
    }

    const admin = await User.create({
      name: adminName,
      email: adminEmail,
      password: adminPassword,
      role: ROLES.ORG_ADMIN,
      organization: organization._id,
      department: createdDepts[0]?._id,
    });

    await createAuditLog({
      organization: organization._id,
      user: admin._id,
      action: 'organization_created',
      entityType: 'Organization',
      entityId: organization._id,
      metadata: { orgType: organizationType },
      ipAddress: req.ip,
    });

    const token = signAccessToken({ id: admin._id, role: admin.role, org: organization._id });

    apiResponse(res, 201, {
      organization,
      template,
      departments: createdDepts,
      admin: sanitizeUser(admin),
      token,
    }, 'Organization onboarded successfully');
  } catch (err) {
    next(err);
  }
};

function sanitizeUser(user) {
  const obj = user.toObject ? user.toObject() : { ...user };
  delete obj.password;
  delete obj.resetPasswordToken;
  delete obj.resetPasswordExpires;
  return obj;
}
