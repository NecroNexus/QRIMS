import User from '../models/User.js';
import Department from '../models/Department.js';
import Category from '../models/Category.js';
import Location from '../models/Location.js';
import InventoryTemplate from '../models/InventoryTemplate.js';
import Notification from '../models/Notification.js';
import AuditLog from '../models/AuditLog.js';
import Supplier from '../models/Supplier.js';
import { getOrganizationPredictions, getDemandPrediction } from '../services/predictionService.js';
import { apiResponse, apiError, paginate } from '../utils/helpers.js';
import { ROLES } from '../config/constants.js';

export const listUsers = async (req, res, next) => {
  try {
    const users = await User.find({ organization: req.organizationId }).select('-password').populate('department', 'name');
    apiResponse(res, 200, { users });
  } catch (err) {
    next(err);
  }
};

export const updateUser = async (req, res, next) => {
  try {
    const user = await User.findOne({ _id: req.params.id, organization: req.organizationId });
    if (!user) return apiError(res, 404, 'User not found');
    if (req.body.role && req.user.role !== ROLES.ORG_ADMIN && req.user.role !== ROLES.SUPER_ADMIN) {
      return apiError(res, 403, 'Cannot change roles');
    }
    Object.assign(user, req.body);
    if (req.body.password) user.password = req.body.password;
    await user.save();
    apiResponse(res, 200, { user: user.toObject({ transform: (_, ret) => { delete ret.password; return ret; } }) });
  } catch (err) {
    next(err);
  }
};

export const crudDepartment = {
  list: async (req, res, next) => {
    try {
      const departments = await Department.find({ organization: req.organizationId }).populate('manager', 'name');
      apiResponse(res, 200, { departments });
    } catch (err) { next(err); }
  },
  create: async (req, res, next) => {
    try {
      const dept = await Department.create({ ...req.body, organization: req.organizationId });
      apiResponse(res, 201, { department: dept });
    } catch (err) { next(err); }
  },
  update: async (req, res, next) => {
    try {
      const dept = await Department.findOneAndUpdate(
        { _id: req.params.id, organization: req.organizationId },
        req.body,
        { new: true }
      );
      if (!dept) return apiError(res, 404, 'Department not found');
      apiResponse(res, 200, { department: dept });
    } catch (err) { next(err); }
  },
};

export const crudCategory = {
  list: async (req, res, next) => {
    try {
      const categories = await Category.find({ organization: req.organizationId });
      apiResponse(res, 200, { categories });
    } catch (err) { next(err); }
  },
  create: async (req, res, next) => {
    try {
      const cat = await Category.create({ ...req.body, organization: req.organizationId });
      apiResponse(res, 201, { category: cat });
    } catch (err) { next(err); }
  },
};

export const crudLocation = {
  list: async (req, res, next) => {
    try {
      const locations = await Location.find({ organization: req.organizationId }).populate('department', 'name');
      apiResponse(res, 200, { locations });
    } catch (err) { next(err); }
  },
  create: async (req, res, next) => {
    try {
      const loc = await Location.create({ ...req.body, organization: req.organizationId });
      apiResponse(res, 201, { location: loc });
    } catch (err) { next(err); }
  },
};

export const getTemplate = async (req, res, next) => {
  try {
    const template = await InventoryTemplate.findOne({ organization: req.organizationId, isDefault: true });
    apiResponse(res, 200, { template });
  } catch (err) { next(err); }
};

export const updateTemplate = async (req, res, next) => {
  try {
    const template = await InventoryTemplate.findOneAndUpdate(
      { organization: req.organizationId, isDefault: true },
      req.body,
      { new: true, upsert: true }
    );
    apiResponse(res, 200, { template });
  } catch (err) { next(err); }
};

export const listNotifications = async (req, res, next) => {
  try {
    const filter = { organization: req.organizationId, user: req.user._id };
    if (req.query.unread === 'true') filter.isRead = false;
    const notifications = await Notification.find(filter).sort('-createdAt').limit(50);
    apiResponse(res, 200, { notifications });
  } catch (err) { next(err); }
};

export const markNotificationRead = async (req, res, next) => {
  try {
    await Notification.updateMany(
      { _id: req.params.id, user: req.user._id },
      { isRead: true }
    );
    apiResponse(res, 200, null, 'Marked as read');
  } catch (err) { next(err); }
};

export const listAuditLogs = async (req, res, next) => {
  try {
    const { action, page, limit } = req.query;
    const filter = { organization: req.organizationId };
    if (action) filter.action = action;
    const query = AuditLog.find(filter).populate('user', 'name email').sort('-createdAt');
    const logs = await paginate(query, { page, limit });
    apiResponse(res, 200, { logs });
  } catch (err) { next(err); }
};

export const getPredictions = async (req, res, next) => {
  try {
    if (req.params.itemId) {
      const prediction = await getDemandPrediction(req.params.itemId);
      return apiResponse(res, 200, { prediction });
    }
    const predictions = await getOrganizationPredictions(req.organizationId);
    apiResponse(res, 200, { predictions });
  } catch (err) { next(err); }
};

export const listSuppliers = async (req, res, next) => {
  try {
    const suppliers = await Supplier.find({ organization: req.organizationId });
    apiResponse(res, 200, { suppliers });
  } catch (err) { next(err); }
};

export const createSupplier = async (req, res, next) => {
  try {
    const supplier = await Supplier.create({ ...req.body, organization: req.organizationId });
    apiResponse(res, 201, { supplier });
  } catch (err) { next(err); }
};
