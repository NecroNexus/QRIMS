import PDFDocument from 'pdfkit';
import { Parser } from 'json2csv';
import InventoryItem from '../models/InventoryItem.js';
import StockTransaction from '../models/StockTransaction.js';
import MaintenanceRequest from '../models/MaintenanceRequest.js';
import AuditLog from '../models/AuditLog.js';
import Organization from '../models/Organization.js';
import Department from '../models/Department.js';
import { apiResponse, apiError } from '../utils/helpers.js';

const parseDateRange = (req) => {
  const from = req.query.from ? new Date(req.query.from) : new Date(Date.now() - 30 * 86400000);
  const to = req.query.to ? new Date(req.query.to) : new Date();
  return { from, to };
};

export const generateReport = async (req, res, next) => {
  try {
    const { type, format = 'json' } = req.query;
    const { from, to } = parseDateRange(req);
    const org = await Organization.findById(req.organizationId);
    if (!org) return apiError(res, 404, 'Organization not found');

    let data = [];
    let title = '';

    switch (type) {
      case 'inventory':
        title = 'Inventory Report';
        data = await InventoryItem.find({ organization: req.organizationId, isDeleted: false })
          .populate('category department', 'name')
          .lean();
        break;
      case 'stock_movement':
        title = 'Stock Movement Report';
        data = await StockTransaction.find({
          organization: req.organizationId,
          createdAt: { $gte: from, $lte: to },
        }).populate('item', 'name qrId').populate('performedBy', 'name').lean();
        break;
      case 'low_stock':
        title = 'Low Stock Report';
        data = await InventoryItem.find({
          organization: req.organizationId,
          isDeleted: false,
          status: { $in: ['low_stock', 'out_of_stock'] },
        }).lean();
        break;
      case 'maintenance':
        title = 'Maintenance Report';
        data = await MaintenanceRequest.find({
          organization: req.organizationId,
          createdAt: { $gte: from, $lte: to },
        }).populate('item', 'name').lean();
        break;
      case 'expiry':
        title = 'Expiry Report';
        data = await InventoryItem.find({
          organization: req.organizationId,
          isDeleted: false,
          expiryDate: { $exists: true, $ne: null },
        }).sort('expiryDate').lean();
        break;
      case 'audit':
        title = 'User Activity Report';
        data = await AuditLog.find({
          organization: req.organizationId,
          createdAt: { $gte: from, $lte: to },
        }).populate('user', 'name email').lean();
        break;
      case 'department':
        title = 'Department Report';
        data = await Department.find({ organization: req.organizationId }).lean();
        break;
      default:
        return apiError(res, 400, 'Invalid report type');
    }

    const meta = {
      organization: org.name,
      orgCode: org.orgCode,
      dateRange: { from, to },
      generatedBy: req.user.name,
      generatedAt: new Date(),
      summary: { totalRecords: data.length },
    };

    if (format === 'csv') {
      const parser = new Parser();
      const csv = parser.parse(data.map(flattenRecord));
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${type}-report.csv"`);
      return res.send(csv);
    }

    if (format === 'pdf') {
      const doc = new PDFDocument({ margin: 50 });
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${type}-report.pdf"`);
      doc.pipe(res);
      doc.fontSize(18).text(title);
      doc.fontSize(10).text(`Organization: ${org.name}`);
      doc.text(`Generated: ${new Date().toLocaleString()} by ${req.user.name}`);
      doc.text(`Records: ${data.length}`);
      doc.moveDown();
      data.slice(0, 100).forEach((row, i) => {
        doc.text(`${i + 1}. ${JSON.stringify(flattenRecord(row)).slice(0, 120)}`);
      });
      doc.end();
      return;
    }

    apiResponse(res, 200, { title, meta, data });
  } catch (err) {
    next(err);
  }
};

function flattenRecord(row) {
  const flat = {};
  for (const [k, v] of Object.entries(row)) {
    if (v && typeof v === 'object' && v._id) flat[k] = v.name || v.email || v._id.toString();
    else if (v instanceof Date) flat[k] = v.toISOString();
    else flat[k] = v;
  }
  return flat;
}
