import { body } from 'express-validator';

export const loginValidation = [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty(),
];

export const registerValidation = [
  body('name').trim().notEmpty(),
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 6 }),
];

export const onboardingValidation = [
  body('organizationName').trim().notEmpty(),
  body('organizationType').notEmpty(),
  body('adminName').trim().notEmpty(),
  body('adminEmail').isEmail().normalizeEmail(),
  body('adminPassword').isLength({ min: 6 }),
];

export const inventoryValidation = [
  body('name').trim().notEmpty(),
  body('quantity').optional().isFloat({ min: 0 }),
  body('cost').optional().isFloat({ min: 0 }),
];

export const stockValidation = [
  body('quantity').isFloat({ min: 0.01 }),
];
