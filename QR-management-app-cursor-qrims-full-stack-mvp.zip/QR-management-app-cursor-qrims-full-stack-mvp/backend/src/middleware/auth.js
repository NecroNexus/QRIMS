import User from '../models/User.js';
import { extractToken, verifyAccessToken } from '../utils/jwt.js';
import { apiError } from '../utils/helpers.js';

export const authenticate = async (req, res, next) => {
  try {
    const token = extractToken(req);
    if (!token) return apiError(res, 401, 'Authentication required');

    const decoded = verifyAccessToken(token);
    const user = await User.findById(decoded.id).select('-password');
    if (!user || !user.isActive) return apiError(res, 401, 'User not found or inactive');

    req.user = user;
    next();
  } catch {
    return apiError(res, 401, 'Invalid or expired token');
  }
};

export const optionalAuth = async (req, res, next) => {
  try {
    const token = extractToken(req);
    if (token) {
      const decoded = verifyAccessToken(token);
      req.user = await User.findById(decoded.id).select('-password');
    }
    next();
  } catch {
    next();
  }
};
