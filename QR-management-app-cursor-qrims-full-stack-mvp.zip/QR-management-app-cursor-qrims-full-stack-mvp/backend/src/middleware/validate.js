import { validationResult } from 'express-validator';
import { apiError } from '../utils/helpers.js';

export const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return apiError(res, 400, 'Validation failed', errors.array());
  }
  next();
};
