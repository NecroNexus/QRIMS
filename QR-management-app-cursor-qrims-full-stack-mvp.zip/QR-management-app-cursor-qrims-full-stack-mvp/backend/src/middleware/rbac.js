import { ROLES, ROLE_HIERARCHY } from '../config/constants.js';
import { apiError } from '../utils/helpers.js';

export const authorize = (...roles) => (req, res, next) => {
  if (!req.user) return apiError(res, 401, 'Authentication required');
  if (!roles.includes(req.user.role)) {
    return apiError(res, 403, 'Insufficient permissions');
  }
  next();
};

export const minRole = (minRole) => (req, res, next) => {
  if (!req.user) return apiError(res, 401, 'Authentication required');
  const userLevel = ROLE_HIERARCHY[req.user.role] || 0;
  const requiredLevel = ROLE_HIERARCHY[minRole] || 0;
  if (userLevel < requiredLevel) {
    return apiError(res, 403, 'Insufficient permissions');
  }
  next();
};

export const requireOrg = (req, res, next) => {
  if (!req.user.organization && req.user.role !== ROLES.SUPER_ADMIN) {
    return apiError(res, 403, 'Organization membership required');
  }
  next();
};

export const enforceOrgIsolation = (req, res, next) => {
  if (req.user.role === ROLES.SUPER_ADMIN) return next();

  const orgFromParams = req.params.organizationId || req.body.organization || req.query.organization;
  const userOrg = req.user.organization?.toString();

  if (orgFromParams && orgFromParams !== userOrg) {
    return apiError(res, 403, 'Access denied to this organization');
  }

  req.organizationId = userOrg;
  next();
};

export const deptManagerScope = async (req, res, next) => {
  if (req.user.role === ROLES.DEPT_MANAGER) {
    req.deptScope = req.user.department?.toString();
  }
  next();
};

export const viewerReadOnly = (req, res, next) => {
  if (req.user.role === ROLES.VIEWER && !['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    return apiError(res, 403, 'Viewer role is read-only');
  }
  next();
};
