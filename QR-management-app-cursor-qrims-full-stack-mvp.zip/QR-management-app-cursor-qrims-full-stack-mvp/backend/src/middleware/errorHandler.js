import { apiError } from '../utils/helpers.js';

export const errorHandler = (err, req, res, _next) => {
  console.error(err);

  if (err.name === 'ValidationError') {
    const messages = Object.values(err.errors).map((e) => e.message);
    return apiError(res, 400, messages.join(', '));
  }

  if (err.code === 11000) {
    const field = Object.keys(err.keyPattern || {})[0] || 'field';
    return apiError(res, 409, `${field} already exists`);
  }

  if (err.name === 'CastError') {
    return apiError(res, 400, 'Invalid ID format');
  }

  if (err.name === 'JsonWebTokenError') {
    return apiError(res, 401, 'Invalid token');
  }

  if (err.name === 'TokenExpiredError') {
    return apiError(res, 401, 'Token expired');
  }

  return apiError(res, err.status || 500, err.message || 'Internal server error');
};

export const notFound = (req, res) => {
  apiError(res, 404, `Route ${req.originalUrl} not found`);
};
