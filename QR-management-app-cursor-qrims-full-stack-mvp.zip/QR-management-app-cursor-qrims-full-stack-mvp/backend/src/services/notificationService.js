import Notification from '../models/Notification.js';
import User from '../models/User.js';
import { ROLES } from '../config/constants.js';

export const createNotification = async ({
  organization,
  userId,
  type,
  title,
  message,
  relatedItem,
  relatedEntity,
  metadata,
}) => {
  return Notification.create({
    organization,
    user: userId,
    type,
    title,
    message,
    relatedItem,
    relatedEntity,
    metadata,
  });
};

export const notifyOrgAdmins = async (organizationId, payload) => {
  const admins = await User.find({
    organization: organizationId,
    role: { $in: [ROLES.ORG_ADMIN, ROLES.DEPT_MANAGER] },
    isActive: true,
  }).select('_id');

  await Promise.all(
    admins.map((admin) =>
      createNotification({ organization: organizationId, userId: admin._id, ...payload })
    )
  );
};

export const checkStockNotifications = async (item, userId) => {
  const reorderPoint = item.reorderConfig?.reorderPoint ?? 10;

  if (item.quantity <= 0) {
    await notifyOrgAdmins(item.organization, {
      type: 'out_of_stock',
      title: 'Out of Stock',
      message: `${item.name} (${item.qrId}) is out of stock.`,
      relatedItem: item._id,
    });
  } else if (item.quantity <= reorderPoint) {
    await notifyOrgAdmins(item.organization, {
      type: 'low_stock',
      title: 'Low Stock Alert',
      message: `${item.name} (${item.qrId}) has ${item.quantity} ${item.unit} remaining.`,
      relatedItem: item._id,
    });
  }
};

export const checkExpiryNotifications = async (item, alertDays) => {
  if (!item.expiryDate) return;
  const daysRemaining = Math.ceil((item.expiryDate - new Date()) / (1000 * 60 * 60 * 24));
  if (alertDays.includes(daysRemaining)) {
    await notifyOrgAdmins(item.organization, {
      type: 'expiring',
      title: 'Expiry Alert',
      message: `${item.name} expires in ${daysRemaining} days.`,
      relatedItem: item._id,
      metadata: { daysRemaining },
    });
  }
};
