import InventoryTemplate from '../models/InventoryTemplate.js';
import Category from '../models/Category.js';
import { ORG_TYPE_TEMPLATES } from '../config/constants.js';

export const createDefaultTemplate = async (organizationId, orgType) => {
  const templateConfig = ORG_TYPE_TEMPLATES[orgType] || ORG_TYPE_TEMPLATES.custom;

  const template = await InventoryTemplate.create({
    organization: organizationId,
    name: `${orgType.charAt(0).toUpperCase() + orgType.slice(1)} Template`,
    orgType,
    fields: templateConfig.fields,
    isDefault: true,
  });

  await Promise.all(
    templateConfig.categories.map((name) =>
      Category.create({ name, organization: organizationId })
    )
  );

  return template;
};

export const validateCustomFields = (fields, customFields = {}) => {
  const errors = [];
  const normalized = {};

  for (const field of fields) {
    const value = customFields[field.key];
    if (field.required && (value === undefined || value === null || value === '')) {
      errors.push(`${field.label} is required`);
      continue;
    }
    if (value !== undefined && value !== null && value !== '') {
      if (field.type === 'number' || field.type === 'currency') {
        const num = Number(value);
        if (Number.isNaN(num)) errors.push(`${field.label} must be a number`);
        else normalized[field.key] = num;
      } else if (field.type === 'boolean') {
        normalized[field.key] = Boolean(value);
      } else if (field.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        errors.push(`${field.label} must be a valid email`);
      } else if (field.type === 'dropdown' && field.options?.length && !field.options.includes(value)) {
        errors.push(`${field.label} must be one of: ${field.options.join(', ')}`);
      } else {
        normalized[field.key] = value;
      }
    }
  }

  return { errors, normalized };
};
