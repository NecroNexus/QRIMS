import QRCode from 'qrcode';

export const generateQrCodeDataUrl = async (qrId) => {
  return QRCode.toDataURL(qrId, {
    errorCorrectionLevel: 'M',
    margin: 2,
    width: 300,
    color: { dark: '#1e293b', light: '#ffffff' },
  });
};

export const generateQrCodeBuffer = async (qrId) => {
  return QRCode.toBuffer(qrId, {
    errorCorrectionLevel: 'M',
    margin: 2,
    width: 300,
  });
};

export const parseQrPayload = (payload) => {
  const trimmed = payload.trim().toUpperCase();
  if (trimmed.startsWith('ITEM-')) return trimmed;
  return trimmed;
};
