import AuditLog from '../models/AuditLog.js';

export const createAuditLog = async ({
  organization,
  user,
  action,
  entityType,
  entityId,
  item,
  metadata,
  ipAddress,
}) => {
  try {
    await AuditLog.create({
      organization,
      user: user?._id || user,
      action,
      entityType,
      entityId,
      item,
      metadata,
      ipAddress,
    });
  } catch (err) {
    console.error('Audit log failed:', err.message);
  }
};
