import { cloudinary, isCloudinaryConfigured } from '../config/cloudinary.js';
import fs from 'fs/promises';

export const uploadImage = async (filePath, folder = 'qrims') => {
  if (isCloudinaryConfigured) {
    const result = await cloudinary.uploader.upload(filePath, {
      folder: `qrims/${folder}`,
      resource_type: 'image',
    });
    await fs.unlink(filePath).catch(() => {});
    return { url: result.secure_url, publicId: result.public_id };
  }

  const localUrl = `/uploads/${filePath.split('/').pop()}`;
  return { url: localUrl, publicId: null };
};

export const deleteImage = async (publicId) => {
  if (publicId && isCloudinaryConfigured) {
    await cloudinary.uploader.destroy(publicId);
  }
};
