import InventoryItem from '../models/InventoryItem.js';
import StockTransaction from '../models/StockTransaction.js';

const movingAverage = (values, window = 3) => {
  if (values.length === 0) return 0;
  const slice = values.slice(-window);
  return slice.reduce((a, b) => a + b, 0) / slice.length;
};

const weightedMovingAverage = (values, window = 3) => {
  if (values.length === 0) return 0;
  const slice = values.slice(-window);
  let weightedSum = 0;
  let weightTotal = 0;
  slice.forEach((val, i) => {
    const weight = i + 1;
    weightedSum += val * weight;
    weightTotal += weight;
  });
  return weightedSum / weightTotal;
};

const linearRegressionPredict = (values) => {
  if (values.length < 2) return values[0] || 0;
  const n = values.length;
  let sumX = 0;
  let sumY = 0;
  let sumXY = 0;
  let sumX2 = 0;
  values.forEach((y, x) => {
    sumX += x;
    sumY += y;
    sumXY += x * y;
    sumX2 += x * x;
  });
  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX || 1);
  const intercept = (sumY - slope * sumX) / n;
  return Math.max(0, Math.round(intercept + slope * n));
};

export const getMonthlyUsage = async (itemId, months = 6) => {
  const startDate = new Date();
  startDate.setMonth(startDate.getMonth() - months);

  const transactions = await StockTransaction.find({
    item: itemId,
    type: 'stock_out',
    createdAt: { $gte: startDate },
  }).sort({ createdAt: 1 });

  const monthly = {};
  transactions.forEach((tx) => {
    const key = `${tx.createdAt.getFullYear()}-${tx.createdAt.getMonth() + 1}`;
    monthly[key] = (monthly[key] || 0) + tx.quantity;
  });

  return Object.values(monthly);
};

export const getDemandPrediction = async (itemId) => {
  const item = await InventoryItem.findById(itemId);
  if (!item) return null;

  const usageHistory = await getMonthlyUsage(itemId);
  const avgUsage = movingAverage(usageHistory, 3);
  const wmaUsage = weightedMovingAverage(usageHistory, 3);
  const predicted = linearRegressionPredict(usageHistory.length ? usageHistory : [avgUsage]);

  const reorderPoint = item.reorderConfig?.reorderPoint ?? 10;
  const maxStock = item.reorderConfig?.maxStock ?? 100;
  const leadTimeDays = item.reorderConfig?.leadTimeDays ?? 7;

  const dailyPredicted = predicted / 30;
  const leadTimeDemand = Math.ceil(dailyPredicted * leadTimeDays);
  const safetyStock = Math.ceil(wmaUsage * 0.2);
  let recommendedReorder = Math.max(0, maxStock - item.quantity);
  if (item.quantity <= reorderPoint) {
    recommendedReorder = Math.max(recommendedReorder, leadTimeDemand + safetyStock);
  }

  return {
    itemId: item._id,
    itemName: item.name,
    currentStock: item.quantity,
    historicalUsage: usageHistory,
    averageMonthlyUsage: Math.round(avgUsage * 10) / 10,
    weightedAverageUsage: Math.round(wmaUsage * 10) / 10,
    predictedNextMonth: predicted,
    recommendedReorderQuantity: recommendedReorder,
    explanation: [
      `Average monthly usage (3-month moving average): ${Math.round(avgUsage)} units.`,
      `Weighted moving average gives more weight to recent months: ${Math.round(wmaUsage)} units.`,
      `Linear regression on ${usageHistory.length} month(s) of data predicts ${predicted} units next month.`,
      item.quantity <= reorderPoint
        ? `Stock (${item.quantity}) is at or below reorder point (${reorderPoint}). Recommended order: ${recommendedReorder} units.`
        : `Stock is above reorder point. Suggested top-up to max stock: ${recommendedReorder} units.`,
    ],
    reorderRecommended: item.quantity <= reorderPoint,
  };
};

export const getOrganizationPredictions = async (organizationId) => {
  const items = await InventoryItem.find({
    organization: organizationId,
    isDeleted: false,
    quantity: { $gte: 0 },
  }).limit(50);

  const predictions = await Promise.all(
    items.map((item) => getDemandPrediction(item._id))
  );
  return predictions.filter(Boolean);
};
