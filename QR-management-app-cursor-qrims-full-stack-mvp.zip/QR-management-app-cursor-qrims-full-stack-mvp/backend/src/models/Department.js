import mongoose from 'mongoose';

const departmentSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    code: { type: String, trim: true },
    organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
    manager: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    description: { type: String },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

departmentSchema.index({ organization: 1, name: 1 }, { unique: true });

export default mongoose.model('Department', departmentSchema);
