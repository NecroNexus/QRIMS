import mongoose from 'mongoose';

const assignmentSchema = new mongoose.Schema(
  {
    organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
    item: { type: mongoose.Schema.Types.ObjectId, ref: 'InventoryItem', required: true },
    assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    assignedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department' },
    status: { type: String, enum: ['active', 'returned', 'cancelled'], default: 'active' },
    assignedAt: { type: Date, default: Date.now },
    returnedAt: { type: Date },
    notes: { type: String },
  },
  { timestamps: true }
);

assignmentSchema.index({ organization: 1, item: 1 });
assignmentSchema.index({ organization: 1, assignedTo: 1 });

export default mongoose.model('Assignment', assignmentSchema);
