import mongoose from 'mongoose';

const supplierSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
    email: { type: String },
    phone: { type: String },
    address: { type: String },
    contactPerson: { type: String },
    leadTimeDays: { type: Number, default: 7 },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

supplierSchema.index({ organization: 1, name: 1 });

export default mongoose.model('Supplier', supplierSchema);
