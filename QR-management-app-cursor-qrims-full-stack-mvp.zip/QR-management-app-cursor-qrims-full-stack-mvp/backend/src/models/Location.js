import mongoose from 'mongoose';

const locationSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    code: { type: String, trim: true },
    organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', default: null },
    address: { type: String },
    floor: { type: String },
    building: { type: String },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

locationSchema.index({ organization: 1, name: 1 });

export default mongoose.model('Location', locationSchema);
