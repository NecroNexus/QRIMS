import mongoose from 'mongoose';

const shipmentSchema = new mongoose.Schema(
  {
    organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
    shipmentNumber: { type: String, required: true },
    type: { type: String, enum: ['incoming', 'outgoing'], required: true },
    status: { type: String, enum: ['pending', 'in_transit', 'delivered', 'cancelled'], default: 'pending' },
    supplier: { type: mongoose.Schema.Types.ObjectId, ref: 'Supplier' },
    destination: { type: String },
    items: [{
      item: { type: mongoose.Schema.Types.ObjectId, ref: 'InventoryItem' },
      quantity: { type: Number, required: true },
    }],
    expectedDate: { type: Date },
    deliveredDate: { type: Date },
    notes: { type: String },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  },
  { timestamps: true }
);

shipmentSchema.index({ organization: 1, shipmentNumber: 1 }, { unique: true });

export default mongoose.model('Shipment', shipmentSchema);
