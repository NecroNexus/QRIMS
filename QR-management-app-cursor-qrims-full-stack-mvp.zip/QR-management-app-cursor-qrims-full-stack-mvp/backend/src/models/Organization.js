import mongoose from 'mongoose';
import { ORG_TYPES } from '../config/constants.js';

const organizationSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    orgCode: { type: String, required: true, unique: true, uppercase: true },
    type: { type: String, enum: ORG_TYPES, required: true },
    isActive: { type: Boolean, default: true },
    onboardingComplete: { type: Boolean, default: false },
    settings: {
      expiryAlertDays: { type: [Number], default: [30, 15, 7] },
      defaultUnit: { type: String, default: 'units' },
      maintenanceIntervalDays: { type: Number, default: 90 },
      modules: {
        maintenance: { type: Boolean, default: true },
        expiry: { type: Boolean, default: true },
        analytics: { type: Boolean, default: true },
        predictions: { type: Boolean, default: true },
        reports: { type: Boolean, default: true },
      },
    },
    address: { type: String },
    contactEmail: { type: String },
    contactPhone: { type: String },
  },
  { timestamps: true }
);

organizationSchema.index({ type: 1 });

export default mongoose.model('Organization', organizationSchema);
