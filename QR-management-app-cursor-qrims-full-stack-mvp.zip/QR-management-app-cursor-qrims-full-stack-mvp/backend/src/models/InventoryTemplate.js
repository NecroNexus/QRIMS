import mongoose from 'mongoose';
import { FIELD_TYPES } from '../config/constants.js';

const fieldDefinitionSchema = new mongoose.Schema(
  {
    key: { type: String, required: true },
    label: { type: String, required: true },
    type: { type: String, enum: FIELD_TYPES, required: true },
    required: { type: Boolean, default: false },
    options: [{ type: String }],
    defaultValue: { type: mongoose.Schema.Types.Mixed },
    validation: {
      min: Number,
      max: Number,
      pattern: String,
    },
  },
  { _id: false }
);

const inventoryTemplateSchema = new mongoose.Schema(
  {
    organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
    name: { type: String, required: true, default: 'Default Template' },
    orgType: { type: String, required: true },
    fields: [fieldDefinitionSchema],
    isDefault: { type: Boolean, default: true },
  },
  { timestamps: true }
);

inventoryTemplateSchema.index({ organization: 1 });

export default mongoose.model('InventoryTemplate', inventoryTemplateSchema);
