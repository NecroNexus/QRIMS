import mongoose from 'mongoose';

const stockTransactionSchema = new mongoose.Schema(
  {
    organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
    item: { type: mongoose.Schema.Types.ObjectId, ref: 'InventoryItem', required: true },
    type: { type: String, enum: ['stock_in', 'stock_out', 'adjustment'], required: true },
    quantity: { type: Number, required: true },
    previousQuantity: { type: Number, required: true },
    newQuantity: { type: Number, required: true },
    performedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    supplier: { type: mongoose.Schema.Types.ObjectId, ref: 'Supplier' },
    referenceNumber: { type: String },
    destination: { type: String },
    reason: { type: String },
    notes: { type: String },
  },
  { timestamps: true }
);

stockTransactionSchema.index({ organization: 1, item: 1, createdAt: -1 });
stockTransactionSchema.index({ organization: 1, createdAt: -1 });

export default mongoose.model('StockTransaction', stockTransactionSchema);
