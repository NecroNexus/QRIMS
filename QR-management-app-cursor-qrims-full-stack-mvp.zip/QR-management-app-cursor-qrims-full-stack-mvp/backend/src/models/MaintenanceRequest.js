import mongoose from 'mongoose';
import { MAINTENANCE_STATUSES, MAINTENANCE_PRIORITIES } from '../config/constants.js';

const maintenanceRequestSchema = new mongoose.Schema(
  {
    organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true },
    item: { type: mongoose.Schema.Types.ObjectId, ref: 'InventoryItem', required: true },
    problem: { type: String, required: true },
    description: { type: String },
    priority: { type: String, enum: MAINTENANCE_PRIORITIES, default: 'medium' },
    status: { type: String, enum: MAINTENANCE_STATUSES, default: 'requested' },
    submittedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    completedAt: { type: Date },
    resolutionNotes: { type: String },
    scheduledDate: { type: Date },
  },
  { timestamps: true }
);

maintenanceRequestSchema.index({ organization: 1, status: 1 });
maintenanceRequestSchema.index({ organization: 1, item: 1 });

export default mongoose.model('MaintenanceRequest', maintenanceRequestSchema);
