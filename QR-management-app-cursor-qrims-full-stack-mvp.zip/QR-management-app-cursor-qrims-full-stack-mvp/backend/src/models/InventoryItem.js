import mongoose from 'mongoose';
import { ITEM_STATUSES } from '../config/constants.js';

const lifecycleEventSchema = new mongoose.Schema(
  {
    event: { type: String, required: true },
    fromStatus: String,
    toStatus: String,
    note: String,
    performedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    metadata: mongoose.Schema.Types.Mixed,
  },
  { timestamps: true }
);

const reorderConfigSchema = new mongoose.Schema(
  {
    minStock: { type: Number, default: 0 },
    maxStock: { type: Number, default: 100 },
    reorderPoint: { type: Number, default: 10 },
    preferredSupplier: { type: mongoose.Schema.Types.ObjectId, ref: 'Supplier' },
    leadTimeDays: { type: Number, default: 7 },
  },
  { _id: false }
);

const inventoryItemSchema = new mongoose.Schema(
  {
    organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true, index: true },
    qrId: { type: String, required: true, unique: true, uppercase: true },
    name: { type: String, required: true, trim: true },
    description: { type: String },
    category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category' },
    quantity: { type: Number, required: true, default: 0, min: 0 },
    unit: { type: String, default: 'units' },
    location: { type: mongoose.Schema.Types.ObjectId, ref: 'Location' },
    department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department' },
    status: { type: String, enum: ITEM_STATUSES, default: 'available' },
    imageUrl: { type: String },
    imagePublicId: { type: String },
    purchaseDate: { type: Date },
    supplier: { type: mongoose.Schema.Types.ObjectId, ref: 'Supplier' },
    cost: { type: Number, default: 0 },
    warrantyExpiry: { type: Date },
    expiryDate: { type: Date },
    customFields: { type: Map, of: mongoose.Schema.Types.Mixed, default: {} },
    assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    reorderConfig: reorderConfigSchema,
    nextMaintenanceDate: { type: Date },
    lifecycleHistory: [lifecycleEventSchema],
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    isDeleted: { type: Boolean, default: false },
  },
  { timestamps: true }
);

inventoryItemSchema.index({ organization: 1, name: 'text', qrId: 'text' });
inventoryItemSchema.index({ organization: 1, status: 1 });
inventoryItemSchema.index({ organization: 1, category: 1 });
inventoryItemSchema.index({ organization: 1, department: 1 });
inventoryItemSchema.index({ organization: 1, expiryDate: 1 });

inventoryItemSchema.methods.updateStatusFromQuantity = function updateStatusFromQuantity() {
  const reorderPoint = this.reorderConfig?.reorderPoint ?? 10;
  if (this.quantity <= 0) {
    this.status = 'out_of_stock';
  } else if (this.quantity <= reorderPoint) {
    if (!['maintenance', 'assigned', 'in_use', 'damaged'].includes(this.status)) {
      this.status = 'low_stock';
    }
  } else if (this.status === 'out_of_stock' || this.status === 'low_stock') {
    this.status = 'available';
  }
};

export default mongoose.model('InventoryItem', inventoryItemSchema);
