import crypto from 'crypto';

export const generateOrgCode = () => {
  const segment = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `ORG${segment}`;
};

export const generateQrId = (orgCode) => {
  const segment = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `ITEM-${orgCode}-${segment}`;
};

export const generateResetToken = () => crypto.randomBytes(32).toString('hex');

export const hashToken = (token) =>
  crypto.createHash('sha256').update(token).digest('hex');

export const paginate = (query, { page = 1, limit = 20, sort = '-createdAt' }) => {
  const skip = (Math.max(1, page) - 1) * limit;
  return query.skip(skip).limit(Math.min(limit, 100)).sort(sort);
};

export const buildSearchRegex = (term) => new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');

export const apiResponse = (res, status, data, message = null) => {
  const body = { success: status < 400, ...(message && { message }), data };
  return res.status(status).json(body);
};

export const apiError = (res, status, message, errors = null) => {
  return res.status(status).json({
    success: false,
    message,
    ...(errors && { errors }),
  });
};
