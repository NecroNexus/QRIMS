import request from 'supertest';
import app from '../src/app.js';
import User from '../src/models/User.js';
import Organization from '../src/models/Organization.js';
import InventoryItem from '../src/models/InventoryItem.js';
import { generateOrgCode, generateQrId } from '../src/utils/helpers.js';
import { ROLES } from '../src/config/constants.js';

describe('Organization Isolation', () => {
  let orgA, orgB, userA, userB, itemA, tokenA, tokenB;

  beforeEach(async () => {
    orgA = await Organization.create({ name: 'Org A', orgCode: generateOrgCode(), type: 'office', onboardingComplete: true });
    orgB = await Organization.create({ name: 'Org B', orgCode: generateOrgCode(), type: 'office', onboardingComplete: true });

    userA = await User.create({ name: 'User A', email: 'a@test.com', password: 'Test@123', role: ROLES.STAFF, organization: orgA._id });
    userB = await User.create({ name: 'User B', email: 'b@test.com', password: 'Test@123', role: ROLES.STAFF, organization: orgB._id });

    itemA = await InventoryItem.create({
      organization: orgA._id,
      qrId: generateQrId(orgA.orgCode),
      name: 'Secret Item A',
      quantity: 10,
      createdBy: userA._id,
    });

    const loginA = await request(app).post('/api/auth/login').send({ email: 'a@test.com', password: 'Test@123' });
    const loginB = await request(app).post('/api/auth/login').send({ email: 'b@test.com', password: 'Test@123' });
    tokenA = loginA.body.data.token;
    tokenB = loginB.body.data.token;
  });

  test('User B cannot access Org A inventory by ID', async () => {
    const res = await request(app)
      .get(`/api/inventory/${itemA._id}`)
      .set('Authorization', `Bearer ${tokenB}`);
    expect(res.status).toBe(404);
  });

  test('User B cannot scan Org A QR code', async () => {
    const res = await request(app)
      .get(`/api/inventory/scan/${itemA.qrId}`)
      .set('Authorization', `Bearer ${tokenB}`);
    expect(res.status).toBe(404);
  });

  test('User A can access own inventory', async () => {
    const res = await request(app)
      .get(`/api/inventory/${itemA._id}`)
      .set('Authorization', `Bearer ${tokenA}`);
    expect(res.status).toBe(200);
    expect(res.body.data.item.name).toBe('Secret Item A');
  });
});

describe('Authentication', () => {
  test('login fails with wrong password', async () => {
    await User.create({ name: 'Test', email: 'test@login.com', password: 'Test@123', role: ROLES.STAFF });
    const res = await request(app).post('/api/auth/login').send({ email: 'test@login.com', password: 'wrong' });
    expect(res.status).toBe(401);
  });

  test('login succeeds with valid credentials', async () => {
    await User.create({ name: 'Test', email: 'valid@login.com', password: 'Test@123', role: ROLES.STAFF });
    const res = await request(app).post('/api/auth/login').send({ email: 'valid@login.com', password: 'Test@123' });
    expect(res.status).toBe(200);
    expect(res.body.data.token).toBeDefined();
  });
});

describe('Stock Transactions', () => {
  let token, item, org, user;

  beforeEach(async () => {
    org = await Organization.create({ name: 'Stock Org', orgCode: generateOrgCode(), type: 'warehouse', onboardingComplete: true });
    user = await User.create({ name: 'Stock User', email: 'stock@test.com', password: 'Test@123', role: ROLES.STAFF, organization: org._id });
    item = await InventoryItem.create({
      organization: org._id,
      qrId: generateQrId(org.orgCode),
      name: 'Widget',
      quantity: 10,
      createdBy: user._id,
    });
    const login = await request(app).post('/api/auth/login').send({ email: 'stock@test.com', password: 'Test@123' });
    token = login.body.data.token;
  });

  test('stock out prevents negative quantity', async () => {
    const res = await request(app)
      .post(`/api/inventory/${item._id}/stock-out`)
      .set('Authorization', `Bearer ${token}`)
      .send({ quantity: 15, reason: 'Test' });
    expect(res.status).toBe(400);
    expect(res.body.message).toMatch(/negative/i);
  });

  test('stock in increases quantity', async () => {
    const res = await request(app)
      .post(`/api/inventory/${item._id}/stock-in`)
      .set('Authorization', `Bearer ${token}`)
      .send({ quantity: 5, referenceNumber: 'PO-001' });
    expect(res.status).toBe(200);
    expect(res.body.data.item.quantity).toBe(15);
  });
});

describe('QR Validation', () => {
  test('QR ID format is secure identifier', () => {
    const qrId = generateQrId('ORGABC');
    expect(qrId).toMatch(/^ITEM-ORGABC-[A-F0-9]{6}$/);
    expect(qrId).not.toContain('@');
    expect(qrId).not.toContain('password');
  });
});
