# QRIMS — Smart Multi-Domain Inventory Management System

QRIMS (QR Inventory Management System) is a production-quality full-stack inventory platform configurable for colleges, hospitals, libraries, warehouses, and other organization types — all powered by a single configurable inventory engine and QR-code identification.

## Features

- **Multi-domain inventory engine** — Configurable field templates per organization type
- **QR code system** — Secure item identifiers with camera scanning (mobile) and generation (API/admin)
- **Role-based access control** — Super Admin, Org Admin, Dept Manager, Staff, Viewer
- **Organization isolation** — Strict data separation between tenants
- **Stock management** — Stock in/out with transaction history and negative-stock prevention
- **Asset lifecycle** — Full audit trail of status transitions
- **Maintenance management** — Request, approve, track repairs
- **Expiry alerts** — Configurable thresholds (30/15/7 days)
- **Notifications** — In-app alerts for stock, expiry, maintenance
- **Analytics dashboard** — Charts for categories, departments, movement
- **Demand prediction** — Moving average, weighted MA, linear regression with explained recommendations
- **Reports** — JSON, CSV, PDF export
- **Audit logging** — All sensitive actions tracked

## Architecture

```
qrims/
├── backend/          # Node.js + Express + MongoDB REST API
├── admin-web/        # React + Vite + Tailwind admin dashboard
├── mobile/           # Flutter Material 3 mobile app
└── docs/             # Documentation
```

## Technology Stack

| Layer | Technologies |
|-------|-------------|
| Mobile | Flutter, Dart, Material 3, mobile_scanner |
| Backend | Node.js, Express, JWT, Mongoose |
| Database | MongoDB |
| Admin Web | React, Vite, Tailwind CSS, Recharts |
| QR | qrcode (generation), mobile_scanner (scanning) |
| Storage | Cloudinary (optional) / local uploads |

## Prerequisites

- Node.js 18+
- MongoDB 6+
- Flutter 3.8+ (for mobile)
- npm

## Installation

### 1. Clone and configure

```bash
cd qrims/backend
cp .env.example .env
# Edit .env with your MongoDB URI and JWT secret
npm install
```

### 2. Seed demo data

```bash
npm run seed
```

### 3. Start backend

```bash
npm run dev
# API: http://localhost:5000
```

### 4. Start admin dashboard

```bash
cd ../admin-web
npm install
npm run dev
# Dashboard: http://localhost:5173
```

### 5. Run mobile app

```bash
cd ../mobile
flutter pub get
flutter run
# Android emulator uses API at http://10.0.2.2:5000/api
# iOS simulator: change baseUrl in lib/core/api_service.dart to http://localhost:5000/api
```

## Environment Variables

See `backend/.env.example`:

| Variable | Description |
|----------|-------------|
| `MONGODB_URI` | MongoDB connection string |
| `JWT_SECRET` | Secret for JWT signing |
| `CORS_ORIGIN` | Allowed frontend origins |
| `CLOUDINARY_*` | Optional image upload credentials |

## Demo Credentials

| Role | Email | Password |
|------|-------|----------|
| Super Admin | superadmin@qrims.io | Super@123 |
| ABC University Admin | admin@abcuniversity.edu | Demo@123 |
| City Hospital Admin | admin@cityhospital.org | Demo@123 |
| Central Library Admin | admin@centrallibrary.org | Demo@123 |
| Tech Warehouse Admin | admin@techwarehouse.com | Demo@123 |
| Staff (any org) | staff@\<domain\> | Demo@123 |

## Demo Flow

1. Login as `admin@abcuniversity.edu`
2. View dashboard analytics and inventory
3. Add a laptop — QR code auto-generated
4. Open mobile app as `staff@abcuniversity.edu`
5. Scan QR or enter QR ID manually
6. Perform stock in/out, submit maintenance request
7. Return to admin — approve maintenance, view transactions
8. Go to Settings → change org type to Hospital → see new template fields
9. View AI Predictions for reorder recommendations
10. Generate reports (CSV/PDF)

## API Documentation

See [docs/api.md](docs/api.md)

## Testing

```bash
cd backend
npm test
```

Key test: Organization A users cannot access Organization B inventory.

## Screenshots

_Add screenshots after running the applications._

## License

MIT
