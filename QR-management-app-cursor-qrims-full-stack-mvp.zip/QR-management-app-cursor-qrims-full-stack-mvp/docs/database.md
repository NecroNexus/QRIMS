# Database Schema

## Collections

| Model | Purpose |
|-------|---------|
| User | Authentication, roles, org membership |
| Organization | Tenant with type and settings |
| Department | Org subdivisions |
| Location | Physical locations |
| InventoryTemplate | Dynamic field definitions |
| Category | Item categorization |
| Supplier | Vendor information |
| InventoryItem | Core inventory with customFields Map |
| StockTransaction | Stock in/out history |
| Assignment | Item-to-user assignments |
| MaintenanceRequest | Maintenance workflow |
| Notification | In-app alerts |
| AuditLog | Action audit trail |
| Shipment | Incoming/outgoing shipments |

## Key Indexes

- `InventoryItem`: organization + status, qrId (unique), text search on name/qrId
- `User`: email (unique), organization + role
- `StockTransaction`: organization + item + createdAt
- `AuditLog`: organization + createdAt

## Organization Isolation

Every tenant-scoped query includes `organization: req.organizationId` derived from the JWT user's record — not from request parameters.
