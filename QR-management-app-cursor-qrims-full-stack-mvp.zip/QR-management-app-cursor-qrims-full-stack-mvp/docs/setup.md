# Setup Guide

## Quick Start (Development)

1. Start MongoDB locally or use MongoDB Atlas
2. Configure `backend/.env`
3. Run `npm run seed` in backend
4. Start backend: `npm run dev`
5. Start admin-web: `npm run dev`
6. Run mobile: `flutter run`

## MongoDB Atlas

Set `MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/qrims`

## Cloudinary (Optional)

Add to `.env`:
```
CLOUDINARY_CLOUD_NAME=your_cloud
CLOUDINARY_API_KEY=your_key
CLOUDINARY_API_SECRET=your_secret
```

Without Cloudinary, images are stored locally in `backend/uploads/`.

## Mobile API URL

- Android emulator: `http://10.0.2.2:5000/api` (default)
- iOS simulator: `http://localhost:5000/api`
- Physical device: Use your machine's LAN IP

Run with custom URL:
```bash
flutter run --dart-define=API_URL=http://192.168.1.100:5000/api
```

## Production Checklist

- [ ] Set strong JWT_SECRET
- [ ] Configure CORS_ORIGIN
- [ ] Enable MongoDB authentication
- [ ] Set up Cloudinary or S3 for images
- [ ] Use HTTPS reverse proxy (nginx)
- [ ] Set NODE_ENV=production
