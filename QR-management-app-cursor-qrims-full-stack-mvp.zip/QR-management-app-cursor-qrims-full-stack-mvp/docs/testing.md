# Testing

## Run Tests

```bash
cd backend
npm test
```

## Test Coverage

| Suite | Tests |
|-------|-------|
| Organization Isolation | Cross-org access blocked |
| Authentication | Login success/failure |
| Stock Transactions | Negative stock prevention, stock in |
| QR Validation | Secure ID format |

## Manual Testing Checklist

- [ ] Onboarding creates org + template + categories
- [ ] Login returns JWT
- [ ] Inventory CRUD with custom fields
- [ ] QR scan returns item for same org only
- [ ] Stock out blocked when insufficient
- [ ] Maintenance workflow (request → approve → complete)
- [ ] Analytics dashboard loads
- [ ] Report generation (JSON/CSV)
- [ ] Org type change updates template

## Organization Isolation Test

The automated test verifies that User B (Org B) receives 404 when accessing Org A's inventory by ID or QR code — even with a valid JWT.
