# Architecture

## Overview

QRIMS uses a monorepo with three clients sharing one REST API and MongoDB database.

```
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│  Admin Web  │  │   Mobile    │  │  Super Admin│
│   (React)   │  │  (Flutter)  │  │   (Web)     │
└──────┬──────┘  └──────┬──────┘  └──────┬──────┘
       │                │                │
       └────────────────┼────────────────┘
                        │ HTTPS / JWT
                 ┌──────▼──────┐
                 │  Express API │
                 │  + RBAC      │
                 └──────┬──────┘
                        │
                 ┌──────▼──────┐
                 │   MongoDB   │
                 └─────────────┘
```

## Core Design: Multi-Domain Engine

Instead of separate apps per industry, QRIMS uses:

1. **Organization.type** — Selects default template (college, hospital, etc.)
2. **InventoryTemplate** — Defines dynamic fields (type, validation, required)
3. **InventoryItem.customFields** — Stores domain-specific values as a Map
4. **Shared services** — QR, stock, maintenance, analytics work identically

Changing organization type regenerates the default template with industry-specific fields while preserving the same API and UI patterns.

## Security Layers

1. JWT authentication on all protected routes
2. Role hierarchy enforced in middleware
3. Organization ID injected from authenticated user (never trusted from client)
4. Department scoping for dept managers
5. Viewer read-only enforcement
6. Rate limiting and Helmet headers

## QR Code Design

QR payloads contain only opaque identifiers: `ITEM-ORG123-8F29A`

No sensitive data (names, costs, user info) is embedded in QR codes.
