# API Reference

Base URL: `http://localhost:5000/api`

## Authentication

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /auth/onboarding | Create organization + admin |
| POST | /auth/login | Login, returns JWT |
| POST | /auth/register | Register user (auth required) |
| GET | /auth/me | Current user |
| POST | /auth/forgot-password | Request reset token |
| POST | /auth/reset-password | Reset with token |

## Inventory

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /inventory | List items (paginated, filterable) |
| POST | /inventory | Create item + QR |
| GET | /inventory/:id | Get item |
| PUT | /inventory/:id | Update item |
| DELETE | /inventory/:id | Soft delete |
| GET | /inventory/scan/:qrId | Scan lookup |
| POST | /inventory/:id/stock-in | Stock in |
| POST | /inventory/:id/stock-out | Stock out |
| GET | /inventory/:id/transactions | Transaction history |
| GET | /inventory/:id/qr | QR code image |
| GET | /inventory/search?q= | Global search |

## Maintenance

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /maintenance | List requests |
| POST | /maintenance | Create request |
| PUT | /maintenance/:id | Update status |

## Analytics & Reports

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /analytics | Dashboard data |
| GET | /reports?type=&format= | Generate report |
| GET | /predictions | Demand forecasts |

## Response Format

```json
{
  "success": true,
  "message": "Optional message",
  "data": { }
}
```
